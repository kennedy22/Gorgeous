# Gorgeous Investment ERP - Installation Guide

## System Requirements
- Windows 10 (64-bit)
- Minimum 4GB RAM
- 10GB free disk space
- Administrator access

## 1. Install PostgreSQL 17

1. Download PostgreSQL 17:
   - Visit: https://www.postgresql.org/download/windows/
   - Download the Windows x64 installer

2. Install PostgreSQL:
   - Run the installer as administrator
   - Select components:
     - [x] PostgreSQL Server
     - [x] pgAdmin 4
     - [x] Command Line Tools
   - Choose installation directory (default: C:\Program Files\PostgreSQL\17)
   - Set password for database superuser (postgres)
   - Set port number to 5050 (Important: Change from default 5432)
   - Click Install

3. Verify Installation:
   - Open Command Prompt
   - Type: `psql --version`
   - Should show: `psql (PostgreSQL) 17.x`

## 2. Create Database

1. Open pgAdmin 4
2. Right-click on "Servers" → "PostgreSQL 17" → Enter your password
3. Right-click on "Databases" → "Create" → "Database"
4. Enter:
   - Database: gorgeous_investment
   - Owner: postgres
5. Click Save

## 3. Deploy ERP Application

1. Extract the ERP package:
   - Create folder: C:\GorgeousInvestmentERP
   - Extract the zip file contents to this folder

2. First-Time Setup:
   - Double-click `GorgeousInvestmentERP.exe`
   - Follow the setup wizard prompts:
     - Enter PostgreSQL connection details (use port 5050)
     - Configure other API credentials
   - The application will start automatically after setup

## 4. Create Desktop Shortcut (Optional)

1. Right-click on Desktop → New → Shortcut
2. Browse to: C:\GorgeousInvestmentERP\GorgeousInvestmentERP.exe
3. Name: "Gorgeous Investment ERP"

## Troubleshooting

If you encounter any issues:

1. Database Connection:
   - Verify PostgreSQL is running (Services app)
   - Check connection string format (ensure port is 5050)
   - Ensure firewall allows PostgreSQL on port 5050

2. Application Won't Start:
   - Check if configuration is saved correctly
   - Verify all credentials are correct
   - Run as administrator first time

For support: support@gorgeousinvestment.com

