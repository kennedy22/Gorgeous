"use client"

import { useState, useEffect } from "react"
import { DocumentCustomizer, type DocumentTemplate } from "@/components/DocumentCustomizer"
import { PrintableDocument } from "@/components/PrintableDocument"
import { Button } from "@/components/ui/button"
import { toast } from "@/components/ui/use-toast"

export default function DocumentTemplatesPage() {
  const [templates, setTemplates] = useState<DocumentTemplate[]>([])
  const [selectedTemplate, setSelectedTemplate] = useState<DocumentTemplate | null>(null)
  const [isCustomizing, setIsCustomizing] = useState(false)

  useEffect(() => {
    fetchTemplates()
  }, [])

  const fetchTemplates = async () => {
    try {
      const response = await fetch("/api/document-templates")
      if (!response.ok) throw new Error("Failed to fetch templates")
      const data = await response.json()
      setTemplates(data)
    } catch (error) {
      console.error("Error fetching templates:", error)
      toast({
        title: "Error",
        description: "Failed to fetch document templates.",
        variant: "destructive",
      })
    }
  }

  const handleSaveTemplate = async (template: DocumentTemplate) => {
    try {
      const method = template.id ? "PUT" : "POST"
      const url = template.id ? `/api/document-templates/${template.id}` : "/api/document-templates"
      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(template),
      })
      if (!response.ok) throw new Error("Failed to save template")
      await fetchTemplates()
      setIsCustomizing(false)
      toast({
        title: "Success",
        description: "Document template saved successfully.",
      })
    } catch (error) {
      console.error("Error saving template:", error)
      toast({
        title: "Error",
        description: "Failed to save document template.",
        variant: "destructive",
      })
    }
  }

  const renderTemplate = (template: DocumentTemplate) => (
    <div style={{ fontFamily: template.fontFamily, fontSize: `${template.fontSize}px` }}>
      {template.headerImage && (
        <img src={template.headerImage || "/placeholder.svg"} alt="Header" className="mb-4 max-w-full" />
      )}
      <div dangerouslySetInnerHTML={{ __html: template.content }} />
      {template.footerText && <div className="mt-4 text-sm text-gray-500">{template.footerText}</div>}
    </div>
  )

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Document Templates</h1>
      {isCustomizing ? (
        <DocumentCustomizer onSave={handleSaveTemplate} initialTemplate={selectedTemplate || undefined} />
      ) : (
        <>
          <Button
            onClick={() => {
              setSelectedTemplate(null)
              setIsCustomizing(true)
            }}
          >
            Create New Template
          </Button>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {templates.map((template) => (
              <div key={template.id} className="border p-4 rounded-lg">
                <h2 className="text-xl font-semibold mb-2">{template.name}</h2>
                <div className="space-x-2">
                  <Button onClick={() => setSelectedTemplate(template)}>View</Button>
                  <Button
                    onClick={() => {
                      setSelectedTemplate(template)
                      setIsCustomizing(true)
                    }}
                  >
                    Edit
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
      {selectedTemplate && !isCustomizing && (
        <PrintableDocument documentTitle={selectedTemplate.name}>{renderTemplate(selectedTemplate)}</PrintableDocument>
      )}
    </div>
  )
}

