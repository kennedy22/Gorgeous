"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface CustomOrder {
  id: string
  customerId: string
  productId: string
  fabric: string
  design: string
  size: string
  status: string
}

export default function CustomOrdersPage() {
  const [orders, setOrders] = useState<CustomOrder[]>([])
  const [newOrder, setNewOrder] = useState<Partial<CustomOrder>>({})

  useEffect(() => {
    fetchOrders()
  }, [])

  async function fetchOrders() {
    try {
      const response = await fetch("/api/sales/custom-orders")
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      const data = await response.json()
      setOrders(data)
    } catch (error) {
      console.error("Failed to fetch custom orders:", error)
      toast({
        title: "Error",
        description: "Failed to load custom orders. Please try again later.",
        variant: "destructive",
      })
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    try {
      const response = await fetch("/api/sales/custom-orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newOrder),
      })
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      await fetchOrders()
      setNewOrder({})
      toast({
        title: "Success",
        description: "Custom order created successfully.",
      })
    } catch (error) {
      console.error("Failed to create custom order:", error)
      toast({
        title: "Error",
        description: "Failed to create custom order. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Custom Orders</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input
          placeholder="Customer ID"
          value={newOrder.customerId || ""}
          onChange={(e) => setNewOrder({ ...newOrder, customerId: e.target.value })}
        />
        <Input
          placeholder="Product ID"
          value={newOrder.productId || ""}
          onChange={(e) => setNewOrder({ ...newOrder, productId: e.target.value })}
        />
        <Select value={newOrder.fabric} onValueChange={(value) => setNewOrder({ ...newOrder, fabric: value })}>
          <SelectTrigger>
            <SelectValue placeholder="Select Fabric" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="cotton">Cotton</SelectItem>
            <SelectItem value="leather">Leather</SelectItem>
            <SelectItem value="polyester">Polyester</SelectItem>
          </SelectContent>
        </Select>
        <Select value={newOrder.design} onValueChange={(value) => setNewOrder({ ...newOrder, design: value })}>
          <SelectTrigger>
            <SelectValue placeholder="Select Design" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="modern">Modern</SelectItem>
            <SelectItem value="classic">Classic</SelectItem>
            <SelectItem value="contemporary">Contemporary</SelectItem>
          </SelectContent>
        </Select>
        <Select value={newOrder.size} onValueChange={(value) => setNewOrder({ ...newOrder, size: value })}>
          <SelectTrigger>
            <SelectValue placeholder="Select Size" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="small">Small</SelectItem>
            <SelectItem value="medium">Medium</SelectItem>
            <SelectItem value="large">Large</SelectItem>
          </SelectContent>
        </Select>
        <Button type="submit">Create Custom Order</Button>
      </form>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>ID</TableHead>
            <TableHead>Customer ID</TableHead>
            <TableHead>Product ID</TableHead>
            <TableHead>Fabric</TableHead>
            <TableHead>Design</TableHead>
            <TableHead>Size</TableHead>
            <TableHead>Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {orders.map((order) => (
            <TableRow key={order.id}>
              <TableCell>{order.id}</TableCell>
              <TableCell>{order.customerId}</TableCell>
              <TableCell>{order.productId}</TableCell>
              <TableCell>{order.fabric}</TableCell>
              <TableCell>{order.design}</TableCell>
              <TableCell>{order.size}</TableCell>
              <TableCell>{order.status}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

