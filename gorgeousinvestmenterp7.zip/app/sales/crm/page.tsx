"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface CustomerInteraction {
  id: string
  customerId: string
  date: string
  type: string
  notes: string
}

export default function CRMPage() {
  const [interactions, setInteractions] = useState<CustomerInteraction[]>([])
  const [newInteraction, setNewInteraction] = useState<Partial<CustomerInteraction>>({})

  useEffect(() => {
    fetchInteractions()
  }, [])

  async function fetchInteractions() {
    try {
      const response = await fetch("/api/sales/crm")
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      const data = await response.json()
      setInteractions(data)
    } catch (error) {
      console.error("Failed to fetch customer interactions:", error)
      toast({
        title: "Error",
        description: "Failed to load customer interactions. Please try again later.",
        variant: "destructive",
      })
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    try {
      const response = await fetch("/api/sales/crm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newInteraction),
      })
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      await fetchInteractions()
      setNewInteraction({})
      toast({
        title: "Success",
        description: "Customer interaction recorded successfully.",
      })
    } catch (error) {
      console.error("Failed to record customer interaction:", error)
      toast({
        title: "Error",
        description: "Failed to record customer interaction. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Customer Relationship Management</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input
          placeholder="Customer ID"
          value={newInteraction.customerId || ""}
          onChange={(e) => setNewInteraction({ ...newInteraction, customerId: e.target.value })}
        />
        <Input
          type="date"
          value={newInteraction.date || ""}
          onChange={(e) => setNewInteraction({ ...newInteraction, date: e.target.value })}
        />
        <Input
          placeholder="Interaction Type"
          value={newInteraction.type || ""}
          onChange={(e) => setNewInteraction({ ...newInteraction, type: e.target.value })}
        />
        <Textarea
          placeholder="Notes"
          value={newInteraction.notes || ""}
          onChange={(e) => setNewInteraction({ ...newInteraction, notes: e.target.value })}
        />
        <Button type="submit">Record Interaction</Button>
      </form>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>ID</TableHead>
            <TableHead>Customer ID</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Notes</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {interactions.map((interaction) => (
            <TableRow key={interaction.id}>
              <TableCell>{interaction.id}</TableCell>
              <TableCell>{interaction.customerId}</TableCell>
              <TableCell>{interaction.date}</TableCell>
              <TableCell>{interaction.type}</TableCell>
              <TableCell>{interaction.notes}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

