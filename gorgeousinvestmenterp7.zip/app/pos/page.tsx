"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface Product {
  id: number
  name: string
  price: number
  stockQuantity: number
}

interface CartItem extends Product {
  quantity: number
}

export default function POSPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [cart, setCart] = useState<CartItem[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [total, setTotal] = useState(0)

  useEffect(() => {
    fetchProducts()
  }, [])

  useEffect(() => {
    calculateTotal()
  }, [cart])

  const fetchProducts = async () => {
    try {
      const response = await fetch("/api/pos/products")
      if (!response.ok) throw new Error("Failed to fetch products")
      const data = await response.json()
      setProducts(data)
    } catch (error) {
      console.error("Error fetching products:", error)
      toast({
        title: "Error",
        description: "Failed to load products. Please try again.",
        variant: "destructive",
      })
    }
  }

  const addToCart = (product: Product) => {
    const existingItem = cart.find((item) => item.id === product.id)
    if (existingItem) {
      setCart(cart.map((item) => (item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item)))
    } else {
      setCart([...cart, { ...product, quantity: 1 }])
    }
  }

  const removeFromCart = (productId: number) => {
    setCart(cart.filter((item) => item.id !== productId))
  }

  const updateQuantity = (productId: number, newQuantity: number) => {
    if (newQuantity < 1) return
    setCart(cart.map((item) => (item.id === productId ? { ...item, quantity: newQuantity } : item)))
  }

  const calculateTotal = () => {
    const newTotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
    setTotal(newTotal)
  }

  const handleCheckout = async () => {
    try {
      const response = await fetch("/api/pos/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ items: cart }),
      })
      if (!response.ok) throw new Error("Checkout failed")
      const data = await response.json()
      toast({
        title: "Success",
        description: `Order #${data.orderId} completed. Total: $${data.total.toFixed(2)}`,
      })
      setCart([])
      fetchProducts() // Refresh product list to update stock quantities
    } catch (error) {
      console.error("Error during checkout:", error)
      toast({
        title: "Error",
        description: "Checkout failed. Please try again.",
        variant: "destructive",
      })
    }
  }

  const filteredProducts = products.filter((product) => product.name.toLowerCase().includes(searchTerm.toLowerCase()))

  return (
    <div className="flex h-screen">
      <div className="w-2/3 p-4 overflow-y-auto">
        <h1 className="text-3xl font-bold mb-4">Point of Sale</h1>
        <Input
          type="text"
          placeholder="Search products..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="mb-4"
        />
        <div className="grid grid-cols-3 gap-4">
          {filteredProducts.map((product) => (
            <Card key={product.id} className="cursor-pointer" onClick={() => addToCart(product)}>
              <CardHeader>
                <CardTitle>{product.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <p>Price: ${product.price.toFixed(2)}</p>
                <p>In Stock: {product.stockQuantity}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
      <div className="w-1/3 p-4 bg-gray-100">
        <h2 className="text-2xl font-bold mb-4">Cart</h2>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Product</TableHead>
              <TableHead>Quantity</TableHead>
              <TableHead>Price</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {cart.map((item) => (
              <TableRow key={item.id}>
                <TableCell>{item.name}</TableCell>
                <TableCell>
                  <Input
                    type="number"
                    value={item.quantity}
                    onChange={(e) => updateQuantity(item.id, Number.parseInt(e.target.value))}
                    min="1"
                    className="w-16"
                  />
                </TableCell>
                <TableCell>${(item.price * item.quantity).toFixed(2)}</TableCell>
                <TableCell>
                  <Button variant="destructive" size="sm" onClick={() => removeFromCart(item.id)}>
                    Remove
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <div className="mt-4">
          <h3 className="text-xl font-bold">Total: ${total.toFixed(2)}</h3>
          <Button className="mt-2 w-full" onClick={handleCheckout} disabled={cart.length === 0}>
            Checkout
          </Button>
        </div>
      </div>
    </div>
  )
}

