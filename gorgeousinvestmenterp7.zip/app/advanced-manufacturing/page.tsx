"use client"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import AdvancedManufacturingTechnologies from "@/components/amt/AdvancedManufacturingTechnologies"
import ThreeDPrintingManagement from "@/components/amt/3DPrintingManagement"
import PerformanceMetrics from "@/components/amt/PerformanceMetrics"
import PrintingMaterialInventory from "@/components/amt/PrintingMaterialInventory"
import ThreeDPrinterControl from "@/components/amt/3DPrinterControl"
import AdvancedAnalytics from "@/components/amt/AdvancedAnalytics"

export default function AdvancedManufacturingPage() {
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Advanced Manufacturing Technologies</h1>
      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="3d-printing">3D Printing</TabsTrigger>
          <TabsTrigger value="performance">Performance Metrics</TabsTrigger>
          <TabsTrigger value="inventory">Material Inventory</TabsTrigger>
          <TabsTrigger value="printer-control">Printer Control</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>
        <TabsContent value="overview">
          <AdvancedManufacturingTechnologies />
        </TabsContent>
        <TabsContent value="3d-printing">
          <ThreeDPrintingManagement />
        </TabsContent>
        <TabsContent value="performance">
          <PerformanceMetrics />
        </TabsContent>
        <TabsContent value="inventory">
          <PrintingMaterialInventory />
        </TabsContent>
        <TabsContent value="printer-control">
          <ThreeDPrinterControl />
        </TabsContent>
        <TabsContent value="analytics">
          <AdvancedAnalytics />
        </TabsContent>
      </Tabs>
    </div>
  )
}

