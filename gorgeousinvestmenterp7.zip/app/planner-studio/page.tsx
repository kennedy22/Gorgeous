import { PlannerStudio } from "@/components/PlannerStudio"

export default function PlannerStudioPage() {
  return (
    <div className="h-screen">
      <h1 className="text-3xl font-bold mb-4">Planner Studio</h1>
      <PlannerStudio />
    </div>
  )
}

