"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface InventoryItem {
  id: string
  name: string
  storeId: string
  quantity: number
  reorderPoint: number
}

export default function MultiStoreInventoryPage() {
  const [inventory, setInventory] = useState<InventoryItem[]>([])
  const [newItem, setNewItem] = useState<Partial<InventoryItem>>({})
  const [selectedStore, setSelectedStore] = useState<string>("all")

  useEffect(() => {
    fetchInventory()
  }, []) // Removed selectedStore from dependencies

  async function fetchInventory() {
    try {
      const response = await fetch(`/api/inventory?storeId=${selectedStore}`)
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      const data = await response.json()
      setInventory(data)
    } catch (error) {
      console.error("Failed to fetch inventory:", error)
      toast({
        title: "Error",
        description: "Failed to load inventory. Please try again later.",
        variant: "destructive",
      })
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    try {
      const response = await fetch("/api/inventory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newItem),
      })
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      await fetchInventory()
      setNewItem({})
      toast({
        title: "Success",
        description: "Inventory item added successfully.",
      })
    } catch (error) {
      console.error("Failed to add inventory item:", error)
      toast({
        title: "Error",
        description: "Failed to add inventory item. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Multi-Store Inventory Management</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input
          placeholder="Item Name"
          value={newItem.name || ""}
          onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
        />
        <Select value={newItem.storeId} onValueChange={(value) => setNewItem({ ...newItem, storeId: value })}>
          <SelectTrigger>
            <SelectValue placeholder="Select Store" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="store1">Store 1</SelectItem>
            <SelectItem value="store2">Store 2</SelectItem>
            <SelectItem value="store3">Store 3</SelectItem>
            <SelectItem value="store4">Store 4</SelectItem>
          </SelectContent>
        </Select>
        <Input
          type="number"
          placeholder="Quantity"
          value={newItem.quantity || ""}
          onChange={(e) => setNewItem({ ...newItem, quantity: Number.parseInt(e.target.value) })}
        />
        <Input
          type="number"
          placeholder="Reorder Point"
          value={newItem.reorderPoint || ""}
          onChange={(e) => setNewItem({ ...newItem, reorderPoint: Number.parseInt(e.target.value) })}
        />
        <Button type="submit">Add Item</Button>
      </form>
      <div>
        <Select value={selectedStore} onValueChange={setSelectedStore}>
          <SelectTrigger>
            <SelectValue placeholder="Select Store" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Stores</SelectItem>
            <SelectItem value="store1">Store 1</SelectItem>
            <SelectItem value="store2">Store 2</SelectItem>
            <SelectItem value="store3">Store 3</SelectItem>
            <SelectItem value="store4">Store 4</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>ID</TableHead>
            <TableHead>Name</TableHead>
            <TableHead>Store</TableHead>
            <TableHead>Quantity</TableHead>
            <TableHead>Reorder Point</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {inventory.map((item) => (
            <TableRow key={item.id}>
              <TableCell>{item.id}</TableCell>
              <TableCell>{item.name}</TableCell>
              <TableCell>{item.storeId}</TableCell>
              <TableCell>{item.quantity}</TableCell>
              <TableCell>{item.reorderPoint}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

