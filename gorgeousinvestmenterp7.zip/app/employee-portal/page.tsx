"use client"

import { useState, useEffect } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function EmployeePortalPage() {
  const [payrollHistory, setPayrollHistory] = useState([])

  useEffect(() => {
    fetchPayrollHistory()
  }, [])

  const fetchPayrollHistory = async () => {
    // Fetch payroll history for the logged-in employee
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Employee Portal</h1>

      <div>
        <h2 className="text-2xl font-semibold">Payroll History</h2>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Pay Period</TableHead>
              <TableHead>Gross Salary</TableHead>
              <TableHead>Deductions</TableHead>
              <TableHead>Net Salary</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {payrollHistory.map((payroll) => (
              <TableRow key={payroll.id}>
                <TableCell>{payroll.payPeriod}</TableCell>
                <TableCell>{payroll.grossSalary}</TableCell>
                <TableCell>{payroll.deductions}</TableCell>
                <TableCell>{payroll.netSalary}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

