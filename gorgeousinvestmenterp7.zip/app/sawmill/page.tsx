"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function SawmillPage() {
  const [productions, setProductions] = useState([])
  const [newProduction, setNewProduction] = useState({ woodType: "", quantity: 0, unit: "cubic meters" })

  useEffect(() => {
    fetchProductions()
  }, [])

  const fetchProductions = async () => {
    // Fetch sawmill productions from API
  }

  const handleInputChange = (e) => {
    setNewProduction({ ...newProduction, [e.target.name]: e.target.value })
  }

  const addProduction = async () => {
    // Add new production record
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Sawmill Production</h1>

      <div className="space-y-4">
        <Input name="woodType" value={newProduction.woodType} onChange={handleInputChange} placeholder="Wood Type" />
        <Input
          type="number"
          name="quantity"
          value={newProduction.quantity}
          onChange={handleInputChange}
          placeholder="Quantity"
        />
        <Input name="unit" value={newProduction.unit} onChange={handleInputChange} placeholder="Unit" />
        <Button onClick={addProduction}>Add Production</Button>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Date</TableHead>
            <TableHead>Wood Type</TableHead>
            <TableHead>Quantity</TableHead>
            <TableHead>Unit</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {productions.map((production) => (
            <TableRow key={production.id}>
              <TableCell>{production.date}</TableCell>
              <TableCell>{production.woodType}</TableCell>
              <TableCell>{production.quantity}</TableCell>
              <TableCell>{production.unit}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

