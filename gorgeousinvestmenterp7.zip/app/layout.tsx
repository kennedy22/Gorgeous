import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import Sidebar from "@/components/Sidebar"
import { SetupWizard } from "@/components/SetupWizard"
import { ConfigProvider } from "@/components/ConfigProvider"
import { ThemeProvider } from "@/components/theme-provider"
import { NotificationCenter } from "@/components/NotificationCenter"
import { AppearanceProvider } from "@/contexts/AppearanceContext"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Gorgeous Investment ERP",
  description: "Comprehensive ERP solution for businesses",
  generator: "v0.dev",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          <ConfigProvider>
            <AppearanceProvider>
              {({ isConfigured }) =>
                isConfigured ? (
                  <div className="flex flex-col md:flex-row h-screen">
                    <Sidebar />
                    <main className="flex-1 overflow-y-auto p-4 md:p-8">
                      <div className="flex justify-end mb-4">
                        <NotificationCenter />
                      </div>
                      {children}
                    </main>
                  </div>
                ) : (
                  <SetupWizard />
                )
              }
            </AppearanceProvider>
          </ConfigProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'