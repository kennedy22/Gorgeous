"use client"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import EmployeeManagement from "@/components/hr/EmployeeManagement"
import TimeAttendance from "@/components/hr/TimeAttendance"
import LeaveManagement from "@/components/hr/LeaveManagement"
import PerformanceEvaluations from "@/components/hr/PerformanceEvaluations"
import Recruitment from "@/components/hr/Recruitment"
import Onboarding from "@/components/hr/Onboarding"

export default function HRPage() {
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Human Resources</h1>
      <Tabs defaultValue="employees">
        <TabsList>
          <TabsTrigger value="employees">Employees</TabsTrigger>
          <TabsTrigger value="time-attendance">Time & Attendance</TabsTrigger>
          <TabsTrigger value="leave">Leave Management</TabsTrigger>
          <TabsTrigger value="performance">Performance Evaluations</TabsTrigger>
          <TabsTrigger value="recruitment">Recruitment</TabsTrigger>
          <TabsTrigger value="onboarding">Onboarding</TabsTrigger>
        </TabsList>
        <TabsContent value="employees">
          <EmployeeManagement />
        </TabsContent>
        <TabsContent value="time-attendance">
          <TimeAttendance />
        </TabsContent>
        <TabsContent value="leave">
          <LeaveManagement />
        </TabsContent>
        <TabsContent value="performance">
          <PerformanceEvaluations />
        </TabsContent>
        <TabsContent value="recruitment">
          <Recruitment />
        </TabsContent>
        <TabsContent value="onboarding">
          <Onboarding />
        </TabsContent>
      </Tabs>
    </div>
  )
}

