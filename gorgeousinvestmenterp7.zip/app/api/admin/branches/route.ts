import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session || session.user.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query("SELECT * FROM branches ORDER BY company_id, name")
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching branches:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session || session.user.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { companyId, name, address } = await request.json()
    const client = await pool.connect()
    const result = await client.query(
      "INSERT INTO branches (company_id, name, address) VALUES ($1, $2, $3) RETURNING *",
      [companyId, name, address],
    )
    client.release()
    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error("Error creating branch:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

