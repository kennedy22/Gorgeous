import { NextResponse } from "next/server"
import os from "os"

export async function GET() {
  try {
    const cpuUsage = (os.loadavg()[0] / os.cpus().length) * 100
    const totalMem = os.totalmem()
    const freeMem = os.freemem()
    const memoryUsage = ((totalMem - freeMem) / totalMem) * 100

    // Simulating response time calculation
    // In a real-world scenario, you'd want to implement a more accurate way to measure this
    const responseTime = Math.random() * 100 + 50 // Random value between 50-150ms

    return NextResponse.json({
      cpuUsage,
      memoryUsage,
      responseTime,
    })
  } catch (error) {
    console.error("Error fetching system metrics:", error)
    return NextResponse.json({ error: "Failed to fetch system metrics" }, { status: 500 })
  }
}

