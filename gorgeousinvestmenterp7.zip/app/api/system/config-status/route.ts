import { NextResponse } from "next/server"
import { readFileSync, existsSync } from "fs"
import path from "path"

export async function GET() {
  const configPath = path.join(process.cwd(), "config.json")

  if (existsSync(configPath)) {
    const configFile = readFileSync(configPath, "utf8")
    const config = JSON.parse(configFile)

    // Check if all required fields are present
    const isConfigured = [
      "POSTGRES_URL",
      "JWT_SECRET_KEY",
      "TWILIO_ACCOUNT_SID",
      "TWILIO_AUTH_TOKEN",
      "MPESA_CONSUMER_KEY",
      "MPESA_CONSUMER_SECRET",
    ].every((key) => config[key])

    return NextResponse.json({ isConfigured })
  }

  return NextResponse.json({ isConfigured: false })
}

