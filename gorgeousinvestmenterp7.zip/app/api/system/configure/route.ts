import { NextResponse } from "next/server"
import { writeFileSync } from "fs"
import path from "path"

export async function POST(request: Request) {
  try {
    const config = await request.json()
    const configPath = path.join(process.cwd(), "config.json")

    writeFileSync(configPath, JSON.stringify(config, null, 2))

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error configuring system:", error)
    return NextResponse.json({ error: "Failed to configure system" }, { status: 500 })
  }
}

