import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { items } = await request.json()
    const client = await pool.connect()

    // Start a transaction
    await client.query("BEGIN")

    // Create the order
    const orderResult = await client.query(
      "INSERT INTO orders (customer_id, total_amount, status) VALUES ($1, $2, $3) RETURNING id",
      [session.user.id, 0, "Completed"],
    )
    const orderId = orderResult.rows[0].id

    // Insert order items and calculate total amount
    let totalAmount = 0
    for (const item of items) {
      const { id, quantity, price } = item
      await client.query("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES ($1, $2, $3, $4)", [
        orderId,
        id,
        quantity,
        price,
      ])
      totalAmount += quantity * price

      // Update product stock
      await client.query("UPDATE products SET stock_quantity = stock_quantity - $1 WHERE id = $2", [quantity, id])
    }

    // Update order total amount
    await client.query("UPDATE orders SET total_amount = $1 WHERE id = $2", [totalAmount, orderId])

    // Commit the transaction
    await client.query("COMMIT")

    client.release()
    return NextResponse.json({ orderId, total: totalAmount })
  } catch (error) {
    console.error("Error processing POS checkout:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

