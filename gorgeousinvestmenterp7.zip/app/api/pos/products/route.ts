import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query(
      "SELECT id, name, price, stock_quantity FROM products WHERE stock_quantity > 0 ORDER BY name",
    )
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching products for POS:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

