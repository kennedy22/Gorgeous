import { NextResponse } from "next/server"
import pool from "@/lib/db"

export async function POST(request: Request) {
  try {
    const { customerId, design } = await request.json()
    const client = await pool.connect()
    const result = await client.query("INSERT INTO sofa_designs (customer_id, design) VALUES ($1, $2) RETURNING *", [
      customerId,
      JSON.stringify(design),
    ])
    client.release()
    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error("Error saving sofa design:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const customerId = searchParams.get("customerId")

  try {
    const client = await pool.connect()
    let result
    if (customerId) {
      result = await client.query("SELECT * FROM sofa_designs WHERE customer_id = $1", [customerId])
    } else {
      result = await client.query("SELECT * FROM sofa_designs")
    }
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching sofa designs:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

