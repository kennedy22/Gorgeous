import { NextResponse } from "next/server"
import pool from "@/lib/db"

export async function GET() {
  try {
    const client = await pool.connect()
    const result = await client.query("SELECT * FROM document_templates")
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching document templates:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const { name, content, fontSize, fontFamily, headerImage, footerText } = await request.json()
    const client = await pool.connect()
    const result = await client.query(
      "INSERT INTO document_templates (name, content, font_size, font_family, header_image, footer_text) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *",
      [name, content, fontSize, fontFamily, headerImage, footerText],
    )
    client.release()
    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error("Error creating document template:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

