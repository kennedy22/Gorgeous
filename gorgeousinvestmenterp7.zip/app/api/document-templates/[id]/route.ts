import { NextResponse } from "next/server"
import pool from "@/lib/db"

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const { name, content, fontSize, fontFamily, headerImage, footerText } = await request.json()
    const client = await pool.connect()
    const result = await client.query(
      "UPDATE document_templates SET name = $1, content = $2, font_size = $3, font_family = $4, header_image = $5, footer_text = $6 WHERE id = $7 RETURNING *",
      [name, content, fontSize, fontFamily, headerImage, footerText, params.id],
    )
    client.release()
    if (result.rows.length === 0) {
      return NextResponse.json({ error: "Template not found" }, { status: 404 })
    }
    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error("Error updating document template:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const client = await pool.connect()
    const result = await client.query("DELETE FROM document_templates WHERE id = $1 RETURNING *", [params.id])
    client.release()
    if (result.rows.length === 0) {
      return NextResponse.json({ error: "Template not found" }, { status: 404 })
    }
    return NextResponse.json({ message: "Template deleted successfully" })
  } catch (error) {
    console.error("Error deleting document template:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

