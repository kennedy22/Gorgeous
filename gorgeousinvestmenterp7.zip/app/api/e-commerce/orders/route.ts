import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query(`
      SELECT o.id, c.name as customer_name, o.order_date, o.total_amount, o.status
      FROM orders o
      JOIN customers c ON o.customer_id = c.id
      ORDER BY o.order_date DESC
    `)
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching orders:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { customerId, items, shippingAddress, billingAddress } = await request.json()
    const client = await pool.connect()

    // Start a transaction
    await client.query("BEGIN")

    // Create the order
    const orderResult = await client.query(
      "INSERT INTO orders (customer_id, total_amount, status, shipping_address, billing_address) VALUES ($1, $2, $3, $4, $5) RETURNING id",
      [customerId, 0, "Pending", shippingAddress, billingAddress],
    )
    const orderId = orderResult.rows[0].id

    // Insert order items and calculate total amount
    let totalAmount = 0
    for (const item of items) {
      const { productId, quantity, price } = item
      await client.query("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES ($1, $2, $3, $4)", [
        orderId,
        productId,
        quantity,
        price,
      ])
      totalAmount += quantity * price

      // Update product stock
      await client.query("UPDATE products SET stock_quantity = stock_quantity - $1 WHERE id = $2", [
        quantity,
        productId,
      ])
    }

    // Update order total amount
    await client.query("UPDATE orders SET total_amount = $1 WHERE id = $2", [totalAmount, orderId])

    // Commit the transaction
    await client.query("COMMIT")

    client.release()
    return NextResponse.json({ id: orderId, totalAmount })
  } catch (error) {
    console.error("Error creating order:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

