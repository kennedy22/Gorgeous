import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query(`
      SELECT p.id, p.name as product_name, p.stock_quantity, p.reorder_point
      FROM products p
      ORDER BY p.name
    `)
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching inventory:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

