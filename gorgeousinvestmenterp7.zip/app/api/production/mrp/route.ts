import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query(`
      SELECT 
        p.id,
        p.name AS product_name,
        COALESCE(bom.required_quantity, 0) AS required_quantity,
        p.stock_quantity AS available_quantity,
        GREATEST(COALESCE(bom.required_quantity, 0) - p.stock_quantity, 0) AS order_quantity
      FROM 
        products p
      LEFT JOIN (
        SELECT 
          component_id,
          SUM(quantity) AS required_quantity
        FROM 
          bill_of_materials
        GROUP BY 
          component_id
      ) bom ON p.id = bom.component_id
      ORDER BY 
        p.name
    `)
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching MRP data:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

