import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { productionOrder, quantity } = await request.json()
    const client = await pool.connect()

    // Start a transaction
    await client.query("BEGIN")

    // Get the bill of materials for the production order
    const bomResult = await client.query(
      `
      SELECT 
        b.component_id,
        b.quantity * $2 AS required_quantity,
        p.stock_quantity AS available_quantity
      FROM 
        bill_of_materials b
      JOIN 
        products p ON b.component_id = p.id
      WHERE 
        b.product_id = $1
    `,
      [productionOrder, quantity],
    )

    // Calculate required materials and update inventory
    for (const item of bomResult.rows) {
      const orderQuantity = Math.max(item.required_quantity - item.available_quantity, 0)
      if (orderQuantity > 0) {
        // Create purchase order or production order for the required materials
        await client.query(
          `
          INSERT INTO purchase_orders (product_id, quantity, status)
          VALUES ($1, $2, 'Pending')
        `,
          [item.component_id, orderQuantity],
        )
      }
    }

    // Create production order
    await client.query(
      `
      INSERT INTO production_orders (product_id, quantity, status)
      VALUES ($1, $2, 'Planned')
    `,
      [productionOrder, quantity],
    )

    // Commit the transaction
    await client.query("COMMIT")

    client.release()
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error running MRP:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

