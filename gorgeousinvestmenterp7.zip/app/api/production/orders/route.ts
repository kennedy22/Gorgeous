import { NextResponse } from "next/server"
import { withAuth } from "@/lib/auth/auth"
import { getDb, setDb } from "@/lib/db/db"

async function handler(req: Request) {
  if (req.method === "GET") {
    const orders = getDb().orders
    return NextResponse.json(orders)
  }

  if (req.method === "POST") {
    const { customerId, items, status } = await req.json()
    const newOrder = {
      id: Math.random().toString(36).substr(2, 9),
      customerId,
      items,
      status,
      createdAt: new Date().toISOString(),
    }
    const db = getDb()
    db.orders.push(newOrder)
    setDb(db)
    return NextResponse.json(newOrder)
  }

  return NextResponse.json({ error: "Method not allowed" }, { status: 405 })
}

export const GET = withAuth(handler)
export const POST = withAuth(handler)

