import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { startDate, endDate } = await request.json()
    const client = await pool.connect()

    // Start a transaction
    await client.query("BEGIN")

    // Get all planned production orders within the date range
    const ordersResult = await client.query(
      `
      SELECT 
        po.id,
        po.product_id,
        po.quantity,
        p.name AS product_name
      FROM 
        production_orders po
      JOIN 
        products p ON po.product_id = p.id
      WHERE 
        po.status = 'Planned'
        AND po.planned_start_date >= $1
        AND po.planned_end_date <= $2
    `,
      [startDate, endDate],
    )

    // Calculate capacity requirements for each order
    for (const order of ordersResult.rows) {
      const capacityResult = await client.query(
        `
        SELECT 
          r.id AS resource_id,
          r.name AS resource_name,
          r.capacity AS available_capacity,
          SUM(bom.quantity * bom.production_time * $2) AS required_capacity
        FROM 
          bill_of_materials bom
        JOIN 
          resources r ON bom.resource_id = r.id
        WHERE 
          bom.product_id = $1
        GROUP BY 
          r.id, r.name, r.capacity
      `,
        [order.product_id, order.quantity],
      )

      // Check if there's enough capacity and update production order status
      let hasCapacity = true
      for (const resource of capacityResult.rows) {
        if (resource.required_capacity > resource.available_capacity) {
          hasCapacity = false
          break
        }
      }

      if (hasCapacity) {
        await client.query(
          `
          UPDATE production_orders
          SET status = 'Scheduled'
          WHERE id = $1
        `,
          [order.id],
        )
      } else {
        await client.query(
          `
          UPDATE production_orders
          SET status = 'Capacity Constraint'
          WHERE id = $1
        `,
          [order.id],
        )
      }
    }

    // Commit the transaction
    await client.query("COMMIT")

    client.release()
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error running capacity planning:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

