import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query(`
      SELECT 
        r.id,
        r.name AS resource_name,
        r.capacity AS available_capacity,
        COALESCE(SUM(po.quantity * bom.production_time), 0) AS required_capacity,
        CASE 
          WHEN r.capacity > 0 THEN COALESCE(SUM(po.quantity * bom.production_time), 0) / r.capacity * 100
          ELSE 0
        END AS utilization_rate
      FROM 
        resources r
      LEFT JOIN 
        bill_of_materials bom ON r.id = bom.resource_id
      LEFT JOIN 
        production_orders po ON bom.product_id = po.product_id
      WHERE 
        po.status = 'Planned'
      GROUP BY 
        r.id, r.name, r.capacity
      ORDER BY 
        r.name
    `)
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching capacity planning data:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

