import { NextResponse } from "next/server"
import { getDb, setDb } from "@/lib/db/db"

async function handler(req: Request) {
  try {
    const db = getDb()

    if (req.method === "GET") {
      return NextResponse.json(db.bom || [])
    }

    if (req.method === "POST") {
      const { productId, materials, labor, overheadCost } = await req.json()
      const newBom = {
        id: Math.random().toString(36).substr(2, 9),
        productId,
        materials,
        labor,
        overheadCost,
        totalCost: materials.reduce((sum, m) => sum + m.cost, 0) + labor + overheadCost,
        createdAt: new Date().toISOString(),
      }
      db.bom = [...(db.bom || []), newBom]
      setDb(db)
      return NextResponse.json(newBom)
    }

    return NextResponse.json({ error: "Method not allowed" }, { status: 405 })
  } catch (error) {
    console.error("Error in BOM API:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export const GET = handler // Remove withAuth for now to simplify debugging
export const POST = handler // Remove withAuth for now to simplify debugging

