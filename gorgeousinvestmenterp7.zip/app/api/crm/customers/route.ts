import { NextResponse } from "next/server"
import { withAuth } from "@/lib/auth/auth"
import { getDb, setDb } from "@/lib/db/db"

async function handler(req: Request) {
  if (req.method === "GET") {
    const customers = getDb().users.filter((user) => user.role === "customer")
    return NextResponse.json(customers)
  }

  if (req.method === "POST") {
    const { name, email, phone } = await req.json()
    const newCustomer = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      email,
      phone,
      role: "customer",
      createdAt: new Date().toISOString(),
    }
    const db = getDb()
    db.users.push(newCustomer)
    setDb(db)
    return NextResponse.json(newCustomer)
  }

  return NextResponse.json({ error: "Method not allowed" }, { status: 405 })
}

export const GET = withAuth(handler)
export const POST = withAuth(handler)

