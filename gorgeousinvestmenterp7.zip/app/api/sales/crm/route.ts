import { NextResponse } from "next/server"
import pool from "@/lib/db"

export async function GET() {
  try {
    const client = await pool.connect()
    const result = await client.query("SELECT * FROM customer_interactions")
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error in CRM GET API:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const { customerId, date, type, notes } = await request.json()
    const client = await pool.connect()
    const result = await client.query(
      "INSERT INTO customer_interactions (customer_id, date, type, notes) VALUES ($1, $2, $3, $4) RETURNING *",
      [customerId, date, type, notes],
    )
    client.release()
    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error("Error in CRM POST API:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

