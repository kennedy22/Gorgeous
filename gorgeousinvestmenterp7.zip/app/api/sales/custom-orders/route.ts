import { NextResponse } from "next/server"
import pool from "@/lib/db"

export async function GET() {
  try {
    const client = await pool.connect()
    const result = await client.query("SELECT * FROM custom_orders")
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error in custom orders GET API:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const { customerId, productId, fabric, design, size } = await request.json()
    const client = await pool.connect()
    const result = await client.query(
      "INSERT INTO custom_orders (customer_id, product_id, fabric, design, size, status) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *",
      [customerId, productId, fabric, design, size, "Pending"],
    )
    client.release()
    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error("Error in custom orders POST API:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

