import { NextResponse } from "next/server"
import pool from "@/lib/db"

export async function GET() {
  try {
    const client = await pool.connect()
    const result = await client.query("SELECT * FROM advanced_manufacturing_technologies")
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching advanced manufacturing technologies:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const { name, description, implementationStatus, benefits, challenges } = await request.json()
    const client = await pool.connect()
    const result = await client.query(
      "INSERT INTO advanced_manufacturing_technologies (name, description, implementation_status, benefits, challenges) VALUES ($1, $2, $3, $4, $5) RETURNING *",
      [name, description, implementationStatus, benefits, challenges],
    )
    client.release()
    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error("Error creating advanced manufacturing technology:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

