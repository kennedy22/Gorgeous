import { NextResponse } from "next/server"
import pool from "@/lib/db"

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const { name, description, implementationStatus, benefits, challenges } = await request.json()
    const client = await pool.connect()
    const result = await client.query(
      "UPDATE advanced_manufacturing_technologies SET name = $1, description = $2, implementation_status = $3, benefits = $4, challenges = $5 WHERE id = $6 RETURNING *",
      [name, description, implementationStatus, benefits, challenges, params.id],
    )
    client.release()
    if (result.rows.length === 0) {
      return NextResponse.json({ error: "Technology not found" }, { status: 404 })
    }
    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error("Error updating advanced manufacturing technology:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const client = await pool.connect()
    const result = await client.query("DELETE FROM advanced_manufacturing_technologies WHERE id = $1 RETURNING *", [
      params.id,
    ])
    client.release()
    if (result.rows.length === 0) {
      return NextResponse.json({ error: "Technology not found" }, { status: 404 })
    }
    return NextResponse.json({ message: "Technology deleted successfully" })
  } catch (error) {
    console.error("Error deleting advanced manufacturing technology:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

