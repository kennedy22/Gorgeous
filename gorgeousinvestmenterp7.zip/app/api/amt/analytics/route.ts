import { NextResponse } from "next/server"
import pool from "@/lib/db"

export async function GET() {
  try {
    const client = await pool.connect()
    const result = await client.query(`
      SELECT 
        DATE(timestamp) as date,
        AVG(CASE WHEN sensor_type = 'energy' THEN value ELSE NULL END) as energy_consumption,
        AVG(CASE WHEN sensor_type = 'waste' THEN value ELSE NULL END) as material_waste,
        AVG(CASE WHEN sensor_type = 'downtime' THEN value ELSE NULL END) as downtime
      FROM iot_data
      GROUP BY DATE(timestamp)
      ORDER BY DATE(timestamp) DESC
      LIMIT 30
    `)
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching analytics data:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

