import { NextResponse } from "next/server"
import pool from "@/lib/db"

export async function POST(request: Request, { params }: { params: { id: string; action: string } }) {
  try {
    const { id, action } = params
    const client = await pool.connect()

    let status: string

    switch (action) {
      case "start":
        status = "Printing"
        break
      case "stop":
        status = "Idle"
        break
      case "reset":
        status = "Idle"
        break
      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }

    const result = await client.query("UPDATE three_d_printers SET status = $1 WHERE id = $2 RETURNING *", [status, id])
    client.release()

    if (result.rows.length === 0) {
      return NextResponse.json({ error: "Printer not found" }, { status: 404 })
    }

    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error(`Error performing action ${params.action} on 3D printer:`, error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

