import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const callbackData = await request.json()
    console.log("M-Pesa callback received:", callbackData)
    // Process the callback data here (e.g., update transaction status in your database)
    return NextResponse.json({ success: true, message: "Callback processed successfully" })
  } catch (error) {
    console.error("Error processing M-Pesa callback:", error)
    return NextResponse.json({ error: "Failed to process callback" }, { status: 500 })
  }
}

