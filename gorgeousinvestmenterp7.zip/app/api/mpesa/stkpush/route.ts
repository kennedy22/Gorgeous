import { NextResponse } from "next/server"
import { initiateSTKPush } from "@/lib/mpesa"

export async function POST(request: Request) {
  try {
    const { phoneNumber, amount, accountReference, transactionDesc } = await request.json()
    const result = await initiateSTKPush(phoneNumber, amount, accountReference, transactionDesc)
    return NextResponse.json({ success: true, message: "STK push initiated successfully", result })
  } catch (error) {
    console.error("Error in M-Pesa API:", error)
    return NextResponse.json({ error: "Failed to initiate STK push" }, { status: 500 })
  }
}

