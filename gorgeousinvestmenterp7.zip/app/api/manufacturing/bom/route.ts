import { NextResponse } from "next/server"
import pool from "@/lib/db"

export async function GET() {
  try {
    const client = await pool.connect()
    const result = await client.query("SELECT * FROM bom")
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error in BOM GET API:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const { productId, materials, labor, overheadCost } = await request.json()
    const totalCost = materials.reduce((sum: number, m: { cost: number }) => sum + m.cost, 0) + labor + overheadCost

    const client = await pool.connect()
    const result = await client.query(
      "INSERT INTO bom (product_id, materials, labor, overhead_cost, total_cost) VALUES ($1, $2, $3, $4, $5) RETURNING *",
      [productId, JSON.stringify(materials), labor, overheadCost, totalCost],
    )
    client.release()
    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error("Error in BOM POST API:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

