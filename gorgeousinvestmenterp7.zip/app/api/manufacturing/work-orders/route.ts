import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"
import { notificationService } from "@/lib/notificationService"

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { productId, employeeId, status, startDate, endDate } = await request.json()
    const client = await pool.connect()

    const result = await client.query(
      `INSERT INTO work_orders (product_id, employee_id, status, start_date, end_date)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [productId, employeeId, status, startDate, endDate],
    )

    const newWorkOrder = result.rows[0]
    client.release()

    // Send notifications
    const notificationMessage = `New work order created: Order #${newWorkOrder.id} for product ${newWorkOrder.product_id}`

    // Fetch employee phone number (assuming you have a users table with phone numbers)
    const employeeResult = await client.query("SELECT phone_number FROM users WHERE id = $1", [employeeId])
    const employeePhone = employeeResult.rows[0]?.phone_number

    if (employeePhone) {
      try {
        await notificationService.sendSMS(employeePhone, notificationMessage)
        await notificationService.sendWhatsApp(employeePhone, notificationMessage)
      } catch (error) {
        console.error("Error sending notifications:", error)
        // Don't throw here, as we still want to return the created work order
      }
    }

    return NextResponse.json(newWorkOrder)
  } catch (error) {
    console.error("Error creating work order:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

