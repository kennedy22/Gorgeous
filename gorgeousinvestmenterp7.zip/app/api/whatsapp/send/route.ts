import { NextResponse } from "next/server"
import { sendWhatsAppMessage } from "@/lib/whatsapp"

export async function POST(request: Request) {
  try {
    const { to, body } = await request.json()
    const message = await sendWhatsAppMessage(to, body)
    return NextResponse.json({ success: true, message: "WhatsApp message sent successfully", sid: message.sid })
  } catch (error) {
    console.error("Error in WhatsApp API:", error)
    return NextResponse.json({ error: "Failed to send WhatsApp message" }, { status: 500 })
  }
}

