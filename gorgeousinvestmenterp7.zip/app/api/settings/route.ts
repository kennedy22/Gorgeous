import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session || session.user.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query("SELECT * FROM system_settings")
    client.release()

    const settings = result.rows[0] || {}
    return NextResponse.json(settings)
  } catch (error) {
    console.error("Error fetching settings:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session || session.user.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const settings = await request.json()
    const client = await pool.connect()

    // Update or insert settings
    await client.query(
      `
      INSERT INTO system_settings (
        database_url, openai_api_key, twilio_account_sid, twilio_auth_token,
        twilio_phone_number, mpesa_consumer_key, mpesa_consumer_secret,
        mpesa_shortcode, mpesa_passkey, base_url
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      ON CONFLICT (id) DO UPDATE SET
        database_url = EXCLUDED.database_url,
        openai_api_key = EXCLUDED.openai_api_key,
        twilio_account_sid = EXCLUDED.twilio_account_sid,
        twilio_auth_token = EXCLUDED.twilio_auth_token,
        twilio_phone_number = EXCLUDED.twilio_phone_number,
        mpesa_consumer_key = EXCLUDED.mpesa_consumer_key,
        mpesa_consumer_secret = EXCLUDED.mpesa_consumer_secret,
        mpesa_shortcode = EXCLUDED.mpesa_shortcode,
        mpesa_passkey = EXCLUDED.mpesa_passkey,
        base_url = EXCLUDED.base_url
    `,
      [
        settings.databaseUrl,
        settings.openaiApiKey,
        settings.twilioAccountSid,
        settings.twilioAuthToken,
        settings.twilioPhoneNumber,
        settings.mpesaConsumerKey,
        settings.mpesaConsumerSecret,
        settings.mpesaShortcode,
        settings.mpesaPasskey,
        settings.baseUrl,
      ],
    )

    client.release()
    return NextResponse.json({ message: "Settings saved successfully" })
  } catch (error) {
    console.error("Error saving settings:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

