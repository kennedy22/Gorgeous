import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query(
      "SELECT id, subject, status, created_at FROM support_tickets WHERE customer_id = $1 ORDER BY created_at DESC",
      [session.user.id],
    )
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching support tickets:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { subject, description } = await request.json()
    const client = await pool.connect()
    const result = await client.query(
      "INSERT INTO support_tickets (customer_id, subject, description, status, priority) VALUES ($1, $2, $3, $4, $5) RETURNING id",
      [session.user.id, subject, description, "Open", "Medium"],
    )
    client.release()
    return NextResponse.json({ id: result.rows[0].id })
  } catch (error) {
    console.error("Error creating support ticket:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

