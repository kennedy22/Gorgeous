import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query(
      "SELECT id, date, total, status FROM orders WHERE customer_id = $1 ORDER BY date DESC",
      [session.user.id],
    )
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching customer orders:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

