import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"
import { notificationService } from "@/lib/notificationService"

export async function GET(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const { searchParams } = new URL(request.url)
  const status = searchParams.get("status")

  try {
    const client = await pool.connect()
    let query = "SELECT * FROM notifications WHERE user_id = $1"
    const queryParams = [session.user.id]

    if (status) {
      query += " AND status = $2"
      queryParams.push(status)
    }

    query += " ORDER BY created_at DESC"

    const result = await client.query(query, queryParams)
    client.release()

    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching notifications:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { userId, message, type, sendSMS, sendWhatsApp } = await request.json()
    const client = await pool.connect()

    const result = await client.query(
      `INSERT INTO notifications (user_id, message, type) VALUES ($1, $2, $3) RETURNING *`,
      [userId, message, type],
    )

    const newNotification = result.rows[0]

    // Fetch user's phone number
    const userResult = await client.query("SELECT phone_number FROM users WHERE id = $1", [userId])
    const userPhone = userResult.rows[0]?.phone_number

    client.release()

    if (userPhone) {
      if (sendSMS) {
        try {
          await notificationService.sendSMS(userPhone, message)
        } catch (error) {
          console.error("Error sending SMS notification:", error)
        }
      }
      if (sendWhatsApp) {
        try {
          await notificationService.sendWhatsApp(userPhone, message)
        } catch (error) {
          console.error("Error sending WhatsApp notification:", error)
        }
      }
    }

    return NextResponse.json(newNotification)
  } catch (error) {
    console.error("Error creating notification:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

