import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query(`
      SELECT te.id, e.name as employee_name, te.clock_in, te.clock_out
      FROM time_entries te
      JOIN employees e ON te.employee_id = e.id
      ORDER BY te.clock_in DESC
    `)
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching time entries:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { action } = await request.json()
    const client = await pool.connect()
    let result

    if (action === "clockIn") {
      result = await client.query("INSERT INTO time_entries (employee_id, clock_in) VALUES ($1, NOW()) RETURNING *", [
        session.user.id,
      ])
    } else if (action === "clockOut") {
      result = await client.query(
        "UPDATE time_entries SET clock_out = NOW() WHERE employee_id = $1 AND clock_out IS NULL RETURNING *",
        [session.user.id],
      )
    } else {
      throw new Error("Invalid action")
    }

    client.release()
    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error("Error recording time entry:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

