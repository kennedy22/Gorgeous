import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query("SELECT * FROM employees ORDER BY hire_date DESC")
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching employees:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { name, department, position, hireDate, salary } = await request.json()
    const client = await pool.connect()
    const result = await client.query(
      "INSERT INTO employees (name, department, position, hire_date, salary) VALUES ($1, $2, $3, $4, $5) RETURNING *",
      [name, department, position, hireDate, salary],
    )
    client.release()
    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error("Error creating employee:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

