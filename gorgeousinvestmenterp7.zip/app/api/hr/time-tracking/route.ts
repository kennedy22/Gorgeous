import { NextResponse } from "next/server"
import { withAuth } from "@/lib/auth/auth"
import { getDb, setDb } from "@/lib/db/db"

async function handler(req: Request) {
  const db = getDb()

  if (req.method === "GET") {
    return NextResponse.json(db.timeEntries || [])
  }

  if (req.method === "POST") {
    const { employeeId, date, hoursWorked, productionUnits } = await req.json()
    const newTimeEntry = {
      id: Math.random().toString(36).substr(2, 9),
      employeeId,
      date,
      hoursWorked,
      productionUnits,
      createdAt: new Date().toISOString(),
    }
    db.timeEntries = [...(db.timeEntries || []), newTimeEntry]
    setDb(db)
    return NextResponse.json(newTimeEntry)
  }

  return NextResponse.json({ error: "Method not allowed" }, { status: 405 })
}

export const GET = withAuth(handler)
export const POST = withAuth(handler)

