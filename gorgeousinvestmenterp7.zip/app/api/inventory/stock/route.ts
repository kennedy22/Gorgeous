import { NextResponse } from "next/server"

async function handler(req: Request) {
  try {
    if (req.method === "GET") {
      // Here you would typically fetch real-time stock data from your database
      const stockData = [
        { id: "1", name: "Item 1", quantity: 100, reorderPoint: 20 },
        { id: "2", name: "Item 2", quantity: 15, reorderPoint: 30 },
      ]

      // Check for items below reorder point
      const lowStockItems = stockData.filter((item) => item.quantity <= item.reorderPoint)

      if (lowStockItems.length > 0) {
        // In a real application, you might want to send notifications or trigger reorder processes here
        console.log("Low stock alert:", lowStockItems)
      }

      return NextResponse.json(stockData)
    }

    return NextResponse.json({ error: "Method not allowed" }, { status: 405 })
  } catch (error) {
    console.error("Error in stock API:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export const GET = handler // Remove withAuth for now to simplify debugging

