import { NextResponse } from "next/server"
import pool from "@/lib/db"

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const storeId = searchParams.get("storeId")

  try {
    const client = await pool.connect()
    let result
    if (storeId && storeId !== "all") {
      result = await client.query("SELECT * FROM inventory WHERE store_id = $1", [storeId])
    } else {
      result = await client.query("SELECT * FROM inventory")
    }
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching inventory:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const { name, storeId, quantity, reorderPoint } = await request.json()
    const client = await pool.connect()
    const result = await client.query(
      "INSERT INTO inventory (name, store_id, quantity, reorder_point) VALUES ($1, $2, $3, $4) RETURNING *",
      [name, storeId, quantity, reorderPoint],
    )
    client.release()
    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error("Error adding inventory item:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

