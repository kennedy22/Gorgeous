import { NextResponse } from "next/server"
import { getDb, setDb } from "@/lib/db/db"
import { analyzeError } from "@/lib/utils/ai-monitor"

export async function GET() {
  try {
    const db = getDb()
    return NextResponse.json(db.materials || [])
  } catch (error) {
    console.error("Error in materials GET API:", error)
    const errorAnalysis = await analyzeError(error as Error)
    console.log("AI Error Analysis:", errorAnalysis)
    return NextResponse.json({ error: "Internal server error", errorId: Date.now() }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const db = getDb()
    const { name, type, quantity, reorderPoint, unitCost } = await request.json()
    const newMaterial = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      type,
      quantity,
      reorderPoint,
      unitCost,
      createdAt: new Date().toISOString(),
    }
    db.materials = [...(db.materials || []), newMaterial]
    setDb(db)
    return NextResponse.json(newMaterial)
  } catch (error) {
    console.error("Error in materials POST API:", error)
    const errorAnalysis = await analyzeError(error as Error)
    console.log("AI Error Analysis:", errorAnalysis)
    return NextResponse.json({ error: "Internal server error", errorId: Date.now() }, { status: 500 })
  }
}

