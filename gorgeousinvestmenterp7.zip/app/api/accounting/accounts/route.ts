import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query("SELECT id, account_name FROM chart_of_accounts ORDER BY account_number")
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching chart of accounts:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

