import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query(`
      SELECT 
        t.id, 
        t.date, 
        t.description, 
        json_agg(json_build_object(
          'account', coa.account_name, 
          'debit', tl.debit, 
          'credit', tl.credit
        )) as lines
      FROM 
        accounting_transactions t
      JOIN 
        transaction_lines tl ON t.id = tl.transaction_id
      JOIN 
        chart_of_accounts coa ON tl.account_id = coa.id
      GROUP BY 
        t.id, t.date, t.description
      ORDER BY 
        t.date DESC
    `)
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching accounting transactions:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { date, description, lines } = await request.json()
    const client = await pool.connect()

    await client.query("BEGIN")

    const transactionResult = await client.query(
      "INSERT INTO accounting_transactions (date, description) VALUES ($1, $2) RETURNING id",
      [date, description],
    )
    const transactionId = transactionResult.rows[0].id

    for (const line of lines) {
      await client.query(
        "INSERT INTO transaction_lines (transaction_id, account_id, debit, credit) VALUES ($1, $2, $3, $4)",
        [transactionId, line.account, line.debit, line.credit],
      )
    }

    await client.query("COMMIT")
    client.release()

    return NextResponse.json({ id: transactionId })
  } catch (error) {
    console.error("Error creating accounting transaction:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

