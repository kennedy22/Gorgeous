import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query(
      `
      SELECT 
        t.id, 
        t.name, 
        t.start as start, 
        t.end as end, 
        t.progress, 
        t.dependencies,
        p.name as project
      FROM 
        tasks t
      JOIN 
        projects p ON t.project_id = p.id
      WHERE 
        p.company_id = $1
      ORDER BY 
        t.start
    `,
      [session.user.companyId],
    )
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching tasks:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { projectId, name, start, end, progress, dependencies } = await request.json()
    const client = await pool.connect()
    const result = await client.query(
      "INSERT INTO tasks (project_id, name, start, end, progress, dependencies) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *",
      [projectId, name, start, end, progress, dependencies],
    )
    client.release()
    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error("Error creating task:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

