import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query(
      `
      SELECT 
        DATE(created_at) as date, 
        SUM(total_amount) as amount
      FROM 
        orders
      WHERE 
        company_id = $1
      GROUP BY 
        DATE(created_at)
      ORDER BY 
        DATE(created_at)
      LIMIT 30
    `,
      [session.user.companyId],
    )
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching sales data:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

