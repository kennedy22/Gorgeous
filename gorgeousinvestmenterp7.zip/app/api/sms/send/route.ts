import { NextResponse } from "next/server"
import { sendSMS } from "@/lib/sms"

export async function POST(request: Request) {
  try {
    const { to, body } = await request.json()
    const message = await sendSMS(to, body)
    return NextResponse.json({ success: true, message: "SMS sent successfully", sid: message.sid })
  } catch (error) {
    console.error("Error in SMS API:", error)
    return NextResponse.json({ error: "Failed to send SMS" }, { status: 500 })
  }
}

