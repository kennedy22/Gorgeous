import { NextResponse } from "next/server"
import { withAuth } from "@/lib/auth/auth"

async function handler(req: Request) {
  if (req.method === "POST") {
    const { customerId, items } = await req.json()

    // Here you would typically create an invoice in your database
    const invoice = {
      id: Math.random().toString(36).substr(2, 9),
      customerId,
      items,
      total: items.reduce((sum, item) => sum + item.price * item.quantity, 0),
      createdAt: new Date().toISOString(),
    }

    return NextResponse.json(invoice)
  }

  return NextResponse.json({ error: "Method not allowed" }, { status: 405 })
}

export const POST = withAuth(handler)

