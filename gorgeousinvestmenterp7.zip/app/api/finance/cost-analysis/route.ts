import { NextResponse } from "next/server"
import { withAuth } from "@/lib/auth/auth"
import { getDb } from "@/lib/db/db"

async function handler(req: Request) {
  const db = getDb()

  if (req.method === "GET") {
    const { productId } = req.query
    const bom = db.bom.find((b) => b.productId === productId)
    const orders = db.customOrders.filter((o) => o.productId === productId)
    const totalRevenue = orders.reduce((sum, o) => sum + o.price * o.quantity, 0)
    const totalCost = orders.reduce((sum, o) => sum + bom.totalCost * o.quantity, 0)
    const profitMargin = ((totalRevenue - totalCost) / totalRevenue) * 100

    return NextResponse.json({
      productId,
      totalRevenue,
      totalCost,
      profitMargin,
    })
  }

  return NextResponse.json({ error: "Method not allowed" }, { status: 405 })
}

export const GET = withAuth(handler)

