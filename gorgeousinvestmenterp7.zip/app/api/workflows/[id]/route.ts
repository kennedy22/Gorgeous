import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query("SELECT * FROM workflows WHERE id = $1 AND company_id = $2", [
      params.id,
      session.user.companyId,
    ])
    client.release()

    if (result.rows.length === 0) {
      return NextResponse.json({ error: "Workflow not found" }, { status: 404 })
    }

    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error("Error fetching workflow:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { name, description, definition } = await request.json()
    const client = await pool.connect()
    const result = await client.query(
      "UPDATE workflows SET name = $1, description = $2, definition = $3, updated_at = NOW() WHERE id = $4 AND company_id = $5 RETURNING *",
      [name, description, JSON.stringify(definition), params.id, session.user.companyId],
    )
    client.release()

    if (result.rows.length === 0) {
      return NextResponse.json({ error: "Workflow not found" }, { status: 404 })
    }

    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error("Error updating workflow:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query("DELETE FROM workflows WHERE id = $1 AND company_id = $2 RETURNING *", [
      params.id,
      session.user.companyId,
    ])
    client.release()

    if (result.rows.length === 0) {
      return NextResponse.json({ error: "Workflow not found" }, { status: 404 })
    }

    return NextResponse.json({ message: "Workflow deleted successfully" })
  } catch (error) {
    console.error("Error deleting workflow:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

