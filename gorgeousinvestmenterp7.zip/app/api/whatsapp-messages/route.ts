import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function GET() {
  try {
    const client = await pool.connect()
    const result = await client.query(`
      SELECT wm.id, wm.user_id, u.name as user_name, wm.content, wm.type, wm.timestamp
      FROM whatsapp_messages wm
      JOIN users u ON wm.user_id = u.id
      ORDER BY wm.timestamp DESC
      LIMIT 100
    `)
    client.release()
    return NextResponse.json(result.rows)
  } catch (error) {
    console.error("Error fetching WhatsApp messages:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { content, type } = await request.json()
    const client = await pool.connect()
    const result = await client.query(
      "INSERT INTO whatsapp_messages (user_id, content, type) VALUES ($1, $2, $3) RETURNING *",
      [session.user.id, content, type],
    )
    client.release()
    return NextResponse.json(result.rows[0])
  } catch (error) {
    console.error("Error creating WhatsApp message:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

