import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { authOptions } from "@/lib/auth"
import pool from "@/lib/db"

export async function POST(request: Request) {
  const session = await getServerSession(authOptions)
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { event, data } = await request.json()
    const client = await pool.connect()

    // Process the webhook based on the event type
    switch (event) {
      case "new_order":
        // Handle new order event
        await client.query("INSERT INTO orders (customer_id, total, status) VALUES ($1, $2, $3)", [
          data.customerId,
          data.total,
          "Pending",
        ])
        break
      case "payment_received":
        // Handle payment received event
        await client.query("UPDATE invoices SET status = $1 WHERE id = $2", ["Paid", data.invoiceId])
        break
      // Add more event types as needed
      default:
        console.warn(`Unhandled webhook event: ${event}`)
    }

    client.release()
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error processing webhook:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

