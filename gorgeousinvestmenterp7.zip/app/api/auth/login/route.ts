import { NextResponse } from "next/server"
import { generateToken } from "@/lib/auth/auth"

export async function POST(req: Request) {
  const { username, password } = await req.json()

  // Here you would typically check the username and password against your database
  // For this example, we'll use a mock user
  if (username === "admin" && password === "password") {
    const token = generateToken({ id: "1", role: "admin" })
    return NextResponse.json({ token })
  }

  return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
}

