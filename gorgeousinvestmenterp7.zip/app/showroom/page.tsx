"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PlannerStudio } from "@/components/PlannerStudio"

export default function ShowroomPage() {
  const [products, setProducts] = useState([])
  const [showrooms, setShowrooms] = useState([])
  const [selectedProduct, setSelectedProduct] = useState("")
  const [selectedShowroom, setSelectedShowroom] = useState("")
  const [quantity, setQuantity] = useState(1)
  const [customOrderDetails, setCustomOrderDetails] = useState("")
  const [is3DDesign, setIs3DDesign] = useState(false)

  useEffect(() => {
    fetchProducts()
    fetchShowrooms()
  }, [])

  const fetchProducts = async () => {
    // Fetch products from API
  }

  const fetchShowrooms = async () => {
    // Fetch showrooms from API
  }

  const handleSale = async () => {
    // Handle regular sale
  }

  const handleCustomOrder = async () => {
    // Handle custom order
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Showroom Sales and Custom Orders</h1>

      <div className="space-y-4">
        <Select value={selectedShowroom} onValueChange={setSelectedShowroom}>
          <SelectTrigger>
            <SelectValue placeholder="Select Showroom" />
          </SelectTrigger>
          <SelectContent>
            {showrooms.map((showroom) => (
              <SelectItem key={showroom.id} value={showroom.id}>
                {showroom.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={selectedProduct} onValueChange={setSelectedProduct}>
          <SelectTrigger>
            <SelectValue placeholder="Select Product" />
          </SelectTrigger>
          <SelectContent>
            {products.map((product) => (
              <SelectItem key={product.id} value={product.id}>
                {product.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Input
          type="number"
          value={quantity}
          onChange={(e) => setQuantity(Number(e.target.value))}
          placeholder="Quantity"
        />

        <Button onClick={handleSale}>Make Sale</Button>
      </div>

      <div className="space-y-4">
        <h2 className="text-2xl font-semibold">Custom Order</h2>
        <textarea
          className="w-full p-2 border rounded"
          value={customOrderDetails}
          onChange={(e) => setCustomOrderDetails(e.target.value)}
          placeholder="Custom order details"
          rows={4}
        />
        <div className="flex items-center space-x-2">
          <input
            type="checkbox"
            checked={is3DDesign}
            onChange={(e) => setIs3DDesign(e.target.checked)}
            id="3d-design"
          />
          <label htmlFor="3d-design">Use 3D Design System</label>
        </div>
        {is3DDesign && <PlannerStudio />}
        <Button onClick={handleCustomOrder}>Place Custom Order</Button>
      </div>
    </div>
  )
}

