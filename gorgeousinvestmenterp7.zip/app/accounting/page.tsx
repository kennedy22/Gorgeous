"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"

interface Transaction {
  id: string
  date: string
  description: string
  lines: {
    account: string
    debit: number
    credit: number
  }[]
}

export default function AccountingPage() {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [newTransaction, setNewTransaction] = useState<Partial<Transaction>>({
    lines: [{ account: "", debit: 0, credit: 0 }],
  })
  const [accounts, setAccounts] = useState<{ id: string; name: string }[]>([])

  useEffect(() => {
    fetchTransactions()
    fetchAccounts()
  }, [])

  const fetchTransactions = async () => {
    try {
      const response = await fetch("/api/accounting/transactions")
      if (!response.ok) throw new Error("Failed to fetch transactions")
      const data = await response.json()
      setTransactions(data)
    } catch (error) {
      console.error("Error fetching transactions:", error)
      toast({
        title: "Error",
        description: "Failed to load transactions. Please try again.",
        variant: "destructive",
      })
    }
  }

  const fetchAccounts = async () => {
    try {
      const response = await fetch("/api/accounting/accounts")
      if (!response.ok) throw new Error("Failed to fetch accounts")
      const data = await response.json()
      setAccounts(data)
    } catch (error) {
      console.error("Error fetching accounts:", error)
      toast({
        title: "Error",
        description: "Failed to load accounts. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>, index?: number) => {
    const { name, value } = e.target
    if (index !== undefined) {
      setNewTransaction((prev) => ({
        ...prev,
        lines: prev.lines?.map((line, i) => (i === index ? { ...line, [name]: value } : line)),
      }))
    } else {
      setNewTransaction((prev) => ({ ...prev, [name]: value }))
    }
  }

  const handleAddLine = () => {
    setNewTransaction((prev) => ({
      ...prev,
      lines: [...(prev.lines || []), { account: "", debit: 0, credit: 0 }],
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/accounting/transactions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newTransaction),
      })
      if (!response.ok) throw new Error("Failed to add transaction")
      await fetchTransactions()
      setNewTransaction({ lines: [{ account: "", debit: 0, credit: 0 }] })
      toast({
        title: "Success",
        description: "Transaction added successfully.",
      })
    } catch (error) {
      console.error("Error adding transaction:", error)
      toast({
        title: "Error",
        description: "Failed to add transaction. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Accounting & Finance</h1>
      <Tabs defaultValue="general-ledger">
        <TabsList>
          <TabsTrigger value="general-ledger">General Ledger</TabsTrigger>
          <TabsTrigger value="accounts-receivable">Accounts Receivable</TabsTrigger>
          <TabsTrigger value="accounts-payable">Accounts Payable</TabsTrigger>
          <TabsTrigger value="financial-reports">Financial Reports</TabsTrigger>
        </TabsList>
        <TabsContent value="general-ledger">
          <Card>
            <CardHeader>
              <CardTitle>General Ledger</CardTitle>
              <CardDescription>Overview of all financial transactions</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4 mb-4">
                <Input
                  name="date"
                  type="date"
                  value={newTransaction.date || ""}
                  onChange={handleInputChange}
                  placeholder="Date"
                  required
                />
                <Input
                  name="description"
                  value={newTransaction.description || ""}
                  onChange={handleInputChange}
                  placeholder="Description"
                  required
                />
                {newTransaction.lines?.map((line, index) => (
                  <div key={index} className="flex space-x-2">
                    <Select
                      value={line.account}
                      onValueChange={(value) => handleInputChange({ target: { name: "account", value } } as any, index)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select account" />
                      </SelectTrigger>
                      <SelectContent>
                        {accounts.map((account) => (
                          <SelectItem key={account.id} value={account.id}>
                            {account.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Input
                      name="debit"
                      type="number"
                      value={line.debit || ""}
                      onChange={(e) => handleInputChange(e, index)}
                      placeholder="Debit"
                    />
                    <Input
                      name="credit"
                      type="number"
                      value={line.credit || ""}
                      onChange={(e) => handleInputChange(e, index)}
                      placeholder="Credit"
                    />
                  </div>
                ))}
                <Button type="button" onClick={handleAddLine}>
                  Add Line
                </Button>
                <Button type="submit">Add Transaction</Button>
              </form>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Account</TableHead>
                    <TableHead>Debit</TableHead>
                    <TableHead>Credit</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions.map((transaction) =>
                    transaction.lines.map((line, index) => (
                      <TableRow key={`${transaction.id}-${index}`}>
                        {index === 0 && (
                          <>
                            <TableCell rowSpan={transaction.lines.length}>{transaction.date}</TableCell>
                            <TableCell rowSpan={transaction.lines.length}>{transaction.description}</TableCell>
                          </>
                        )}
                        <TableCell>{line.account}</TableCell>
                        <TableCell>{line.debit.toFixed(2)}</TableCell>
                        <TableCell>{line.credit.toFixed(2)}</TableCell>
                      </TableRow>
                    )),
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        {/* Implement other tabs... */}
      </Tabs>
    </div>
  )
}

