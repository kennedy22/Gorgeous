"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface WorkOrder {
  id: string
  productId: string
  employeeId: string
  status: string
  startDate: string
  endDate: string
}

export default function WorkOrdersPage() {
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>([])
  const [newWorkOrder, setNewWorkOrder] = useState<Partial<WorkOrder>>({})

  useEffect(() => {
    fetchWorkOrders()
  }, [])

  async function fetchWorkOrders() {
    try {
      const response = await fetch("/api/manufacturing/work-orders")
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      const data = await response.json()
      setWorkOrders(data)
    } catch (error) {
      console.error("Failed to fetch work orders:", error)
      toast({
        title: "Error",
        description: "Failed to load work orders. Please try again later.",
        variant: "destructive",
      })
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    try {
      const response = await fetch("/api/manufacturing/work-orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newWorkOrder),
      })
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      await fetchWorkOrders()
      setNewWorkOrder({})
      toast({
        title: "Success",
        description: "Work order created successfully.",
      })
    } catch (error) {
      console.error("Failed to create work order:", error)
      toast({
        title: "Error",
        description: "Failed to create work order. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Work Orders</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <Input
          placeholder="Product ID"
          value={newWorkOrder.productId || ""}
          onChange={(e) => setNewWorkOrder({ ...newWorkOrder, productId: e.target.value })}
        />
        <Input
          placeholder="Employee ID"
          value={newWorkOrder.employeeId || ""}
          onChange={(e) => setNewWorkOrder({ ...newWorkOrder, employeeId: e.target.value })}
        />
        <Input
          type="date"
          placeholder="Start Date"
          value={newWorkOrder.startDate || ""}
          onChange={(e) => setNewWorkOrder({ ...newWorkOrder, startDate: e.target.value })}
        />
        <Input
          type="date"
          placeholder="End Date"
          value={newWorkOrder.endDate || ""}
          onChange={(e) => setNewWorkOrder({ ...newWorkOrder, endDate: e.target.value })}
        />
        <Button type="submit">Create Work Order</Button>
      </form>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>ID</TableHead>
            <TableHead>Product ID</TableHead>
            <TableHead>Employee ID</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Start Date</TableHead>
            <TableHead>End Date</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {workOrders.map((order) => (
            <TableRow key={order.id}>
              <TableCell>{order.id}</TableCell>
              <TableCell>{order.productId}</TableCell>
              <TableCell>{order.employeeId}</TableCell>
              <TableCell>{order.status}</TableCell>
              <TableCell>{order.startDate}</TableCell>
              <TableCell>{order.endDate}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

