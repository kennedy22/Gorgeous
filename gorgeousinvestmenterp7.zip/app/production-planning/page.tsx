"use client"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import MRPComponent from "@/components/production/MRPComponent"
import CapacityPlanningComponent from "@/components/production/CapacityPlanningComponent"

export default function ProductionPlanningPage() {
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Production Planning and Scheduling</h1>
      <Tabs defaultValue="mrp">
        <TabsList>
          <TabsTrigger value="mrp">Material Requirements Planning (MRP)</TabsTrigger>
          <TabsTrigger value="capacity">Capacity Planning</TabsTrigger>
        </TabsList>
        <TabsContent value="mrp">
          <MRPComponent />
        </TabsContent>
        <TabsContent value="capacity">
          <CapacityPlanningComponent />
        </TabsContent>
      </Tabs>
    </div>
  )
}

