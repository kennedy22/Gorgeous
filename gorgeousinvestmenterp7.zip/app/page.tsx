"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Package, AlertTriangle, PenToolIcon as Tools } from "lucide-react"
import { Button } from "@/components/ui/button"
import { toast } from "@/components/ui/use-toast"
import { SystemHealth } from "@/components/SystemHealth"
import { useAppearance } from "@/contexts/AppearanceContext"

export default function Home() {
  const [stockData, setStockData] = useState([])
  const [lowStockItems, setLowStockItems] = useState([])
  const [customOrders, setCustomOrders] = useState([])
  const [productionData, setProductionData] = useState([])
  const [loading, setLoading] = useState(true)
  const { appearance } = useAppearance()

  useEffect(() => {
    fetchData()
  }, [])

  async function fetchData() {
    setLoading(true)
    try {
      const stockResponse = await fetch("/api/inventory/materials")
      if (!stockResponse.ok) {
        throw new Error(`HTTP error! status: ${stockResponse.status}`)
      }
      const stockData = await stockResponse.json()
      setStockData(stockData)
      setLowStockItems(stockData.filter((item) => item.quantity <= item.reorderPoint))

      const ordersResponse = await fetch("/api/sales/custom-orders")
      if (!ordersResponse.ok) {
        throw new Error(`HTTP error! status: ${ordersResponse.status}`)
      }
      const ordersData = await ordersResponse.json()
      setCustomOrders(ordersData)

      const productionResponse = await fetch("/api/production/bom")
      if (!productionResponse.ok) {
        throw new Error(`HTTP error! status: ${productionResponse.status}`)
      }
      const productionData = await productionResponse.json()
      setProductionData(productionData)
    } catch (e) {
      console.error("Failed to fetch data:", e)
      toast({
        title: "Error",
        description: "Failed to load data. Please try again later.",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div>Loading...</div>
  }

  const getDashboardLayout = () => {
    switch (appearance.dashboardLayout) {
      case "list":
        return "flex flex-col space-y-4"
      case "compact":
        return "grid grid-cols-2 gap-4"
      case "grid":
      default:
        return "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
    }
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-center">
        <h1 className="text-3xl font-bold mb-4 sm:mb-0">Gorgeous Investment Dashboard</h1>
        <Button onClick={fetchData}>Refresh Data</Button>
      </div>
      <SystemHealth />
      <div className={getDashboardLayout()}>
        <Card style={{ backgroundColor: appearance.secondaryColor, color: appearance.primaryColor }}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Raw Materials</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stockData.length}</div>
            <p className="text-xs text-muted-foreground">Total types of materials</p>
          </CardContent>
        </Card>
        <Card style={{ backgroundColor: appearance.secondaryColor, color: appearance.primaryColor }}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Low Stock Alerts</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{lowStockItems.length}</div>
            <p className="text-xs text-muted-foreground">Materials below reorder point</p>
          </CardContent>
        </Card>
        <Card style={{ backgroundColor: appearance.secondaryColor, color: appearance.primaryColor }}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Custom Orders</CardTitle>
            <Tools className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{customOrders.length}</div>
            <p className="text-xs text-muted-foreground">Pending custom orders</p>
          </CardContent>
        </Card>
        <Card style={{ backgroundColor: appearance.secondaryColor, color: appearance.primaryColor }}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Products</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{productionData.length}</div>
            <p className="text-xs text-muted-foreground">Total product types</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

