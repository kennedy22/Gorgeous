"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import ProductCatalog from "@/components/e-commerce/ProductCatalog"
import OrderManagement from "@/components/e-commerce/OrderManagement"
import InventoryManagement from "@/components/e-commerce/InventoryManagement"

export default function ECommercePage() {
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">E-Commerce Management</h1>
      <Tabs defaultValue="catalog">
        <TabsList>
          <TabsTrigger value="catalog">Product Catalog</TabsTrigger>
          <TabsTrigger value="orders">Order Management</TabsTrigger>
          <TabsTrigger value="inventory">Inventory Management</TabsTrigger>
        </TabsList>
        <TabsContent value="catalog">
          <ProductCatalog />
        </TabsContent>
        <TabsContent value="orders">
          <OrderManagement />
        </TabsContent>
        <TabsContent value="inventory">
          <InventoryManagement />
        </TabsContent>
      </Tabs>
    </div>
  )
}

