"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { toast } from "@/components/ui/use-toast"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"

interface Settings {
  databaseUrl: string
  openaiApiKey: string
  twilioAccountSid: string
  twilioAuthToken: string
  twilioPhoneNumber: string
  mpesaConsumerKey: string
  mpesaConsumerSecret: string
  mpesaShortcode: string
  mpesaPasskey: string
  baseUrl: string
  primaryColor: string
  secondaryColor: string
  accentColor: string
  dashboardLayout: "grid" | "list" | "compact"
  darkMode: boolean
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<Settings>({
    databaseUrl: "",
    openaiApiKey: "",
    twilioAccountSid: "",
    twilioAuthToken: "",
    twilioPhoneNumber: "",
    mpesaConsumerKey: "",
    mpesaConsumerSecret: "",
    mpesaShortcode: "",
    mpesaPasskey: "",
    baseUrl: "",
    primaryColor: "#000000",
    secondaryColor: "#ffffff",
    accentColor: "#3b82f6",
    dashboardLayout: "grid",
    darkMode: false,
  })

  useEffect(() => {
    fetchSettings()
  }, [])

  const fetchSettings = async () => {
    try {
      const response = await fetch("/api/settings")
      if (!response.ok) throw new Error("Failed to fetch settings")
      const data = await response.json()
      setSettings(data)
    } catch (error) {
      console.error("Error fetching settings:", error)
      toast({
        title: "Error",
        description: "Failed to load settings. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setSettings((prev) => ({ ...prev, [name]: value }))
  }

  const handleColorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setSettings((prev) => ({ ...prev, [name]: value }))
  }

  const handleLayoutChange = (value: "grid" | "list" | "compact") => {
    setSettings((prev) => ({ ...prev, dashboardLayout: value }))
  }

  const handleDarkModeToggle = () => {
    setSettings((prev) => ({ ...prev, darkMode: !prev.darkMode }))
  }

  const saveSettings = async () => {
    try {
      const response = await fetch("/api/settings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(settings),
      })
      if (!response.ok) throw new Error("Failed to save settings")
      toast({
        title: "Success",
        description: "Settings saved successfully.",
      })
    } catch (error) {
      console.error("Error saving settings:", error)
      toast({
        title: "Error",
        description: "Failed to save settings. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-4">System Settings</h1>
      <Tabs defaultValue="general">
        <TabsList>
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="appearance">Appearance</TabsTrigger>
          <TabsTrigger value="database">Database</TabsTrigger>
          <TabsTrigger value="api">API Keys</TabsTrigger>
          <TabsTrigger value="communications">Communications</TabsTrigger>
          <TabsTrigger value="mpesa">M-Pesa</TabsTrigger>
        </TabsList>

        <TabsContent value="database">
          <Card>
            <CardHeader>
              <CardTitle>Database Configuration</CardTitle>
              <CardDescription>Configure your database connection settings.</CardDescription>
            </CardHeader>
            <CardContent>
              <Input
                name="databaseUrl"
                value={settings.databaseUrl}
                onChange={handleInputChange}
                placeholder="Database URL"
                className="mb-4"
              />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="api">
          <Card>
            <CardHeader>
              <CardTitle>API Keys</CardTitle>
              <CardDescription>Manage your API keys for various services.</CardDescription>
            </CardHeader>
            <CardContent>
              <Input
                name="openaiApiKey"
                value={settings.openaiApiKey}
                onChange={handleInputChange}
                placeholder="OpenAI API Key"
                className="mb-4"
              />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="communications">
          <Card>
            <CardHeader>
              <CardTitle>Communications Settings</CardTitle>
              <CardDescription>Configure settings for SMS and WhatsApp communications.</CardDescription>
            </CardHeader>
            <CardContent>
              <Input
                name="twilioAccountSid"
                value={settings.twilioAccountSid}
                onChange={handleInputChange}
                placeholder="Twilio Account SID"
                className="mb-4"
              />
              <Input
                name="twilioAuthToken"
                value={settings.twilioAuthToken}
                onChange={handleInputChange}
                placeholder="Twilio Auth Token"
                type="password"
                className="mb-4"
              />
              <Input
                name="twilioPhoneNumber"
                value={settings.twilioPhoneNumber}
                onChange={handleInputChange}
                placeholder="Twilio Phone Number"
                className="mb-4"
              />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="mpesa">
          <Card>
            <CardHeader>
              <CardTitle>M-Pesa Configuration</CardTitle>
              <CardDescription>Set up your M-Pesa integration details.</CardDescription>
            </CardHeader>
            <CardContent>
              <Input
                name="mpesaConsumerKey"
                value={settings.mpesaConsumerKey}
                onChange={handleInputChange}
                placeholder="M-Pesa Consumer Key"
                className="mb-4"
              />
              <Input
                name="mpesaConsumerSecret"
                value={settings.mpesaConsumerSecret}
                onChange={handleInputChange}
                placeholder="M-Pesa Consumer Secret"
                className="mb-4"
              />
              <Input
                name="mpesaShortcode"
                value={settings.mpesaShortcode}
                onChange={handleInputChange}
                placeholder="M-Pesa Shortcode"
                className="mb-4"
              />
              <Input
                name="mpesaPasskey"
                value={settings.mpesaPasskey}
                onChange={handleInputChange}
                placeholder="M-Pesa Passkey"
                className="mb-4"
              />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>General Settings</CardTitle>
              <CardDescription>Configure general system settings.</CardDescription>
            </CardHeader>
            <CardContent>
              <Input
                name="baseUrl"
                value={settings.baseUrl}
                onChange={handleInputChange}
                placeholder="Base URL"
                className="mb-4"
              />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="appearance">
          <Card>
            <CardHeader>
              <CardTitle>Appearance Settings</CardTitle>
              <CardDescription>Customize the look and feel of your ERP system.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="primaryColor">Primary Color</Label>
                  <Input
                    id="primaryColor"
                    name="primaryColor"
                    type="color"
                    value={settings.primaryColor}
                    onChange={handleColorChange}
                  />
                </div>
                <div>
                  <Label htmlFor="secondaryColor">Secondary Color</Label>
                  <Input
                    id="secondaryColor"
                    name="secondaryColor"
                    type="color"
                    value={settings.secondaryColor}
                    onChange={handleColorChange}
                  />
                </div>
                <div>
                  <Label htmlFor="accentColor">Accent Color</Label>
                  <Input
                    id="accentColor"
                    name="accentColor"
                    type="color"
                    value={settings.accentColor}
                    onChange={handleColorChange}
                  />
                </div>
              </div>

              <div>
                <Label>Dashboard Layout</Label>
                <RadioGroup
                  value={settings.dashboardLayout}
                  onValueChange={handleLayoutChange}
                  className="flex space-x-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="grid" id="grid" />
                    <Label htmlFor="grid">Grid</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="list" id="list" />
                    <Label htmlFor="list">List</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="compact" id="compact" />
                    <Label htmlFor="compact">Compact</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="flex items-center space-x-2">
                <Label htmlFor="darkMode">Dark Mode</Label>
                <input
                  id="darkMode"
                  type="checkbox"
                  checked={settings.darkMode}
                  onChange={handleDarkModeToggle}
                  className="toggle"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      <Button onClick={saveSettings} className="mt-4">
        Save Settings
      </Button>
    </div>
  )
}

