"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"

export default function CommunicationsPage() {
  const [phoneNumber, setPhoneNumber] = useState("")
  const [message, setMessage] = useState("")
  const [amount, setAmount] = useState("")

  const sendWhatsApp = async () => {
    try {
      const response = await fetch("/api/whatsapp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ to: phoneNumber, body: message }),
      })
      const data = await response.json()
      if (data.success) {
        toast({ title: "Success", description: "WhatsApp message sent successfully" })
      } else {
        throw new Error(data.error)
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to send WhatsApp message", variant: "destructive" })
    }
  }

  const sendSMS = async () => {
    try {
      const response = await fetch("/api/sms/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ to: phoneNumber, body: message }),
      })
      const data = await response.json()
      if (data.success) {
        toast({ title: "Success", description: "SMS sent successfully" })
      } else {
        throw new Error(data.error)
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to send SMS", variant: "destructive" })
    }
  }

  const initiateMPesaPayment = async () => {
    try {
      const response = await fetch("/api/mpesa/stkpush", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          phoneNumber,
          amount: Number.parseFloat(amount),
          accountReference: "GorgeousInvestment",
          transactionDesc: "Payment for services",
        }),
      })
      const data = await response.json()
      if (data.success) {
        toast({ title: "Success", description: "M-Pesa payment initiated successfully" })
      } else {
        throw new Error(data.error)
      }
    } catch (error) {
      toast({ title: "Error", description: "Failed to initiate M-Pesa payment", variant: "destructive" })
    }
  }

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Communications</h1>
      <div className="space-y-4">
        <Input placeholder="Phone Number" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} />
        <Textarea placeholder="Message" value={message} onChange={(e) => setMessage(e.target.value)} />
        <Input
          type="number"
          placeholder="Amount (for M-Pesa)"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <div className="space-x-4">
          <Button onClick={sendWhatsApp}>Send WhatsApp</Button>
          <Button onClick={sendSMS}>Send SMS</Button>
          <Button onClick={initiateMPesaPayment}>Initiate M-Pesa Payment</Button>
        </div>
      </div>
    </div>
  )
}

