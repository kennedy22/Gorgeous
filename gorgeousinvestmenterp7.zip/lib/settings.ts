import pool from "@/lib/db"

export async function getSettings() {
  try {
    const client = await pool.connect()
    const result = await client.query("SELECT * FROM system_settings")
    client.release()

    return result.rows[0] || {}
  } catch (error) {
    console.error("Error fetching settings:", error)
    return {}
  }
}

