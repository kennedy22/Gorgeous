import { Connection, type SObject } from "jsforce"

export class SalesforceConnector {
  private connection: Connection

  constructor(username: string, password: string, securityToken: string) {
    this.connection = new Connection({
      loginUrl: "https://login.salesforce.com",
    })
    this.login(username, password, securityToken)
  }

  private async login(username: string, password: string, securityToken: string) {
    try {
      await this.connection.login(username, password + securityToken)
    } catch (error) {
      console.error("Error logging into Salesforce:", error)
      throw error
    }
  }

  async createLead(lead: SObject) {
    try {
      const result = await this.connection.sobject("Lead").create(lead)
      return result
    } catch (error) {
      console.error("Error creating lead in Salesforce:", error)
      throw error
    }
  }

  async getOpportunities() {
    try {
      const result = await this.connection.query("SELECT Id, Name, StageName, Amount FROM Opportunity")
      return result.records
    } catch (error) {
      console.error("Error fetching opportunities from Salesforce:", error)
      throw error
    }
  }

  // Add more Salesforce-specific methods as needed
}

