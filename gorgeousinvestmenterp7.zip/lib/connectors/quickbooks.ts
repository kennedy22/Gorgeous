import QuickBooks from "node-quickbooks"

export class QuickBooksConnector {
  private qbo: QuickBooks

  constructor(accessToken: string, realmId: string) {
    this.qbo = new QuickBooks(
      process.env.QUICKBOOKS_CLIENT_ID,
      process.env.QUICKBOOKS_CLIENT_SECRET,
      accessToken,
      false, // don't use sandbox
      realmId,
    )
  }

  async createInvoice(invoice: any) {
    return new Promise((resolve, reject) => {
      this.qbo.createInvoice(invoice, (err, invoice) => {
        if (err) {
          console.error("Error creating invoice in QuickBooks:", err)
          reject(err)
        } else {
          resolve(invoice)
        }
      })
    })
  }

  async getCustomers() {
    return new Promise((resolve, reject) => {
      this.qbo.findCustomers({}, (err, customers) => {
        if (err) {
          console.error("Error fetching customers from QuickBooks:", err)
          reject(err)
        } else {
          resolve(customers)
        }
      })
    })
  }

  // Add more QuickBooks-specific methods as needed
}

