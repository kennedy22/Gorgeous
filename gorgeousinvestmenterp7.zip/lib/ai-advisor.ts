import { Configuration, OpenAIApi } from "openai"

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
})
const openai = new OpenAIApi(configuration)

export async function getAIAdvice(context: string, question: string) {
  try {
    const completion = await openai.createCompletion({
      model: "text-davinci-002",
      prompt: `Context: ${context}\n\nQuestion: ${question}\n\nAdvice:`,
      max_tokens: 150,
    })
    return completion.data.choices[0].text.trim()
  } catch (error) {
    console.error("Error getting AI advice:", error)
    return "Unable to get AI advice at this time."
  }
}

