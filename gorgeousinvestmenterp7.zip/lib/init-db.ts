import pool from "./db"

async function initDatabase() {
  const client = await pool.connect()
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(50) NOT NULL
      );

      CREATE TABLE IF NOT EXISTS inventory (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        store_id VARCHAR(50) NOT NULL,
        quantity INTEGER NOT NULL,
        reorder_point INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS bom (
        id SERIAL PRIMARY KEY,
        product_id VARCHAR(50) NOT NULL,
        materials JSONB NOT NULL,
        labor DECIMAL(10, 2) NOT NULL,
        overhead_cost DECIMAL(10, 2) NOT NULL,
        total_cost DECIMAL(10, 2) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS work_orders (
        id SERIAL PRIMARY KEY,
        product_id VARCHAR(50) NOT NULL,
        employee_id VARCHAR(50) NOT NULL,
        status VARCHAR(50) NOT NULL,
        start_date DATE NOT NULL,
        end_date DATE NOT NULL
      );

      CREATE TABLE IF NOT EXISTS custom_orders (
        id SERIAL PRIMARY KEY,
        customer_id VARCHAR(50) NOT NULL,
        product_id VARCHAR(50) NOT NULL,
        fabric VARCHAR(50) NOT NULL,
        design VARCHAR(50) NOT NULL,
        size VARCHAR(50) NOT NULL,
        status VARCHAR(50) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS customer_interactions (
        id SERIAL PRIMARY KEY,
        customer_id VARCHAR(50) NOT NULL,
        date DATE NOT NULL,
        type VARCHAR(50) NOT NULL,
        notes TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );
    `)
    console.log("Database schema initialized successfully")
  } catch (error) {
    console.error("Error initializing database schema:", error)
  } finally {
    client.release()
  }
}

export default initDatabase

