import { OpenAI } from "openai"

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export async function analyzeError(error: Error): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: "You are an AI assistant specialized in analyzing and providing solutions for software errors.",
        },
        {
          role: "user",
          content: `Analyze this error and suggest a solution: ${error.message}\n\nStack trace: ${error.stack}`,
        },
      ],
    })

    return response.choices[0].message.content || "Unable to analyze error."
  } catch (aiError) {
    console.error("Error in AI error analysis:", aiError)
    return "AI error analysis failed. Please check the logs for more information."
  }
}

export async function optimizePerformance(metrics: any): Promise<string> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4",
      messages: [
        { role: "system", content: "You are an AI assistant specialized in optimizing software performance." },
        {
          role: "user",
          content: `Analyze these performance metrics and suggest optimizations: ${JSON.stringify(metrics)}`,
        },
      ],
    })

    return response.choices[0].message.content || "Unable to suggest optimizations."
  } catch (aiError) {
    console.error("Error in AI performance optimization:", aiError)
    return "AI performance optimization failed. Please check the logs for more information."
  }
}

