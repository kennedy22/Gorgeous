import { Pool } from "pg"

let pool: Pool | null = null

export async function getPool() {
  if (!pool) {
    const config = await window.electron.ipcRenderer.invoke("get-config")
    pool = new Pool({
      connectionString: config.POSTGRES_URL,
      ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
    })
  }
  return pool
}

