import twilio from "twilio"
import { readFileSync } from "fs"
import path from "path"

const configPath = path.join(process.cwd(), "config.json")
const configFile = readFileSync(configPath, "utf8")
const config = JSON.parse(configFile)

const client = twilio(config.TWILIO_ACCOUNT_SID, config.TWILIO_AUTH_TOKEN)

export async function sendWhatsAppMessage(to: string, body: string) {
  try {
    const message = await client.messages.create({
      body: body,
      from: `whatsapp:${config.TWILIO_WHATSAPP_NUMBER}`,
      to: `whatsapp:${to}`,
    })
    console.log(`WhatsApp message sent with SID: ${message.sid}`)
    return message
  } catch (error) {
    console.error("Error sending WhatsApp message:", error)
    throw error
  }
}

