import type { NextAuthOptions } from "next-auth"

export const authOptions: NextAuthOptions = {
  // Configure one or more authentication providers
  providers: [],
  callbacks: {
    async session({ session, token, user }) {
      // Send properties to the client, like an access_token from a provider.
      session.user = session.user || {}
      session.user.id = "1" //mock user id
      session.user.role = "admin" //mock user role
      return session
    },
  },
  secret: process.env.NEXTAUTH_SECRET,
}

