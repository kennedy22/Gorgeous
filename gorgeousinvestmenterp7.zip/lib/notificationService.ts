import twilio from "twilio"
import { getSettings } from "./settings"

class NotificationService {
  private client: twilio.Twilio | null = null

  private async initClient() {
    const settings = await getSettings()
    if (!this.client && settings.twilioAccountSid && settings.twilioAuthToken) {
      this.client = twilio(settings.twilioAccountSid, settings.twilioAuthToken)
    }
  }

  async sendSMS(to: string, body: string) {
    await this.initClient()
    if (!this.client) {
      throw new Error("Twilio client not initialized")
    }

    const settings = await getSettings()
    try {
      const message = await this.client.messages.create({
        body: body,
        from: settings.twilioPhoneNumber,
        to: to,
      })
      console.log("SMS sent:", message.sid)
      return message
    } catch (error) {
      console.error("Error sending SMS:", error)
      throw error
    }
  }

  async sendWhatsApp(to: string, body: string) {
    await this.initClient()
    if (!this.client) {
      throw new Error("Twilio client not initialized")
    }

    const settings = await getSettings()
    try {
      const message = await this.client.messages.create({
        body: body,
        from: `whatsapp:${settings.twilioPhoneNumber}`,
        to: `whatsapp:${to}`,
      })
      console.log("WhatsApp message sent:", message.sid)
      return message
    } catch (error) {
      console.error("Error sending WhatsApp message:", error)
      throw error
    }
  }
}

export const notificationService = new NotificationService()

