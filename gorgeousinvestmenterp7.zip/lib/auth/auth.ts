import { sign, verify } from "jsonwebtoken"
import type { NextApiRequest, NextApiResponse } from "next"

const SECRET_KEY = process.env.JWT_SECRET_KEY

export function generateToken(user: { id: string; role: string }) {
  return sign({ id: user.id, role: user.role }, SECRET_KEY, { expiresIn: "1d" })
}

export function verifyToken(token: string) {
  try {
    return verify(token, SECRET_KEY)
  } catch (error) {
    return null
  }
}

export function withAuth(handler: (req: NextApiRequest, res: NextApiResponse, user: any) => Promise<void>) {
  return async (req: NextApiRequest, res: NextApiResponse) => {
    const token = req.headers.authorization?.split(" ")[1]
    if (!token) {
      return res.status(401).json({ message: "Authentication required" })
    }

    const decoded = verifyToken(token)
    if (!decoded) {
      return res.status(401).json({ message: "Invalid token" })
    }

    return handler(req, res, decoded)
  }
}

