import type { OpenAPIV3 } from "openapi-types"

export const apiDocs: OpenAPIV3.Document = {
  openapi: "3.0.0",
  info: {
    title: "Gorgeous Investment ERP API",
    version: "1.0.0",
    description: "API documentation for Gorgeous Investment ERP system",
  },
  paths: {
    "/api/customer-portal/orders": {
      get: {
        summary: "Get customer orders",
        responses: {
          "200": {
            description: "Successful response",
            content: {
              "application/json": {
                schema: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      id: { type: "integer" },
                      date: { type: "string", format: "date-time" },
                      total: { type: "number" },
                      status: { type: "string" },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/customer-portal/invoices": {
      get: {
        summary: "Get customer invoices",
        responses: {
          "200": {
            description: "Successful response",
            content: {
              "application/json": {
                schema: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      id: { type: "integer" },
                      date: { type: "string", format: "date-time" },
                      amount: { type: "number" },
                      status: { type: "string" },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
    "/api/customer-portal/tickets": {
      get: {
        summary: "Get customer support tickets",
        responses: {
          "200": {
            description: "Successful response",
            content: {
              "application/json": {
                schema: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      id: { type: "integer" },
                      subject: { type: "string" },
                      status: { type: "string" },
                      created_at: { type: "string", format: "date-time" },
                    },
                  },
                },
              },
            },
          },
        },
      },
      post: {
        summary: "Create a new support ticket",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: {
                type: "object",
                properties: {
                  subject: { type: "string" },
                  description: { type: "string" },
                },
                required: ["subject", "description"],
              },
            },
          },
        },
        responses: {
          "200": {
            description: "Successful response",
            content: {
              "application/json": {
                schema: {
                  type: "object",
                  properties: {
                    id: { type: "integer" },
                  },
                },
              },
            },
          },
        },
      },
    },
    // Add more API endpoints here...
  },
}

