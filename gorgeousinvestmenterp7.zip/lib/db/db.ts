let db = {
  users: [],
  inventory: [],
  orders: [],
}

export function getDb() {
  return db
}

export function setDb(newDb) {
  db = newDb
}

