import pgPromise from "pg-promise"

const pgp = pgPromise()

const config = {
  user: process.env.POSTGRES_USER,
  host: process.env.POSTGRES_HOST,
  database: process.env.POSTGRES_DB,
  password: process.env.POSTGRES_PASSWORD,
  port: Number.parseInt(process.env.POSTGRES_PORT || "5432"),
  ssl: { rejectUnauthorized: false }, // Add this line for SSL support
}

const db = pgp(config)

export default db

