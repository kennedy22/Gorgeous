import db, { client } from "./postgres"

async function initDatabase() {
  try {
    await db.none(`
      -- Existing tables...

      -- Advanced Manufacturing Technologies
      CREATE TABLE IF NOT EXISTS advanced_manufacturing_technologies (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        implementation_status VARCHAR(50),
        benefits TEXT,
        challenges TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS iot_data (
        id SERIAL PRIMARY KEY,
        device_id VARCHAR(255) NOT NULL,
        sensor_type VARCHAR(255) NOT NULL,
        value DECIMAL NOT NULL,
        timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS three_d_printers (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        model VARCHAR(255),
        ip_address VARCHAR(15),
        status VARCHAR(50),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS amt_performance_metrics (
        id SERIAL PRIMARY KEY,
        date DATE NOT NULL,
        efficiency DECIMAL,
        quality_rate DECIMAL,
        roi DECIMAL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS printing_materials (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        type VARCHAR(50),
        quantity INTEGER NOT NULL,
        unit VARCHAR(50),
        reorder_point INTEGER,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS sofa_designs (
        id SERIAL PRIMARY KEY,
        customer_id VARCHAR(50) NOT NULL,
        design JSONB NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS api_keys (
        id SERIAL PRIMARY KEY,
        key VARCHAR(255) UNIQUE NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS resources (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        capacity DECIMAL NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS bill_of_materials (
        id SERIAL PRIMARY KEY,
        product_id VARCHAR(50) NOT NULL,
        component_id VARCHAR(50) NOT NULL,
        quantity DECIMAL NOT NULL,
        production_time DECIMAL NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS production_orders (
        id SERIAL PRIMARY KEY,
        product_id VARCHAR(50) NOT NULL,
        quantity DECIMAL NOT NULL,
        status VARCHAR(50) NOT NULL,
        planned_start_date DATE,
        planned_end_date DATE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS support_tickets (
        id SERIAL PRIMARY KEY,
        customer_id VARCHAR(50) NOT NULL,
        subject VARCHAR(255) NOT NULL,
        description TEXT,
        status VARCHAR(50) NOT NULL,
        priority VARCHAR(50) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS system_settings (
        id SERIAL PRIMARY KEY,
        database_url VARCHAR(255),
        openai_api_key VARCHAR(255),
        twilio_account_sid VARCHAR(255),
        twilio_auth_token VARCHAR(255),
        twilio_phone_number VARCHAR(20),
        mpesa_consumer_key VARCHAR(255),
        mpesa_consumer_secret VARCHAR(255),
        mpesa_shortcode VARCHAR(20),
        mpesa_passkey VARCHAR(255),
        base_url VARCHAR(255)
      );

      CREATE TABLE IF NOT EXISTS whatsapp_messages (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(50) NOT NULL,
        content TEXT,
        type VARCHAR(50) NOT NULL,
        timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS employees (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        department VARCHAR(255) NOT NULL,
        position VARCHAR(255) NOT NULL,
        hire_date DATE NOT NULL,
        salary DECIMAL(10, 2) NOT NULL
      );

      CREATE TABLE IF NOT EXISTS leave_requests (
        id SERIAL PRIMARY KEY,
        employee_id VARCHAR(50) NOT NULL,
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        leave_type VARCHAR(50) NOT NULL,
        status VARCHAR(50) NOT NULL
      );

      CREATE TABLE IF NOT EXISTS iot_data (
        id SERIAL PRIMARY KEY,
        device_id VARCHAR(255) NOT NULL,
        sensor_type VARCHAR(255) NOT NULL,
        value DECIMAL NOT NULL,
        timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS three_d_printers (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        model VARCHAR(255),
        ip_address VARCHAR(15),
        status VARCHAR(50),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS amt_performance_metrics (
        id SERIAL PRIMARY KEY,
        date DATE NOT NULL,
        efficiency DECIMAL,
        quality_rate DECIMAL,
        roi DECIMAL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS printing_materials (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        type VARCHAR(50),
        quantity INTEGER NOT NULL,
        unit VARCHAR(50),
        reorder_point INTEGER,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS sofa_designs (
        id SERIAL PRIMARY KEY,
        customer_id VARCHAR(50) NOT NULL,
        design JSONB NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS api_keys (
        id SERIAL PRIMARY KEY,
        key VARCHAR(255) UNIQUE NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS resources (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        capacity DECIMAL NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS bill_of_materials (
        id SERIAL PRIMARY KEY,
        product_id VARCHAR(50) NOT NULL,
        component_id VARCHAR(50) NOT NULL,
        quantity DECIMAL NOT NULL,
        production_time DECIMAL NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS production_orders (
        id SERIAL PRIMARY KEY,
        product_id VARCHAR(50) NOT NULL,
        quantity DECIMAL NOT NULL,
        status VARCHAR(50) NOT NULL,
        planned_start_date DATE,
        planned_end_date DATE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS support_tickets (
        id SERIAL PRIMARY KEY,
        customer_id VARCHAR(50) NOT NULL,
        subject VARCHAR(255) NOT NULL,
        description TEXT,
        status VARCHAR(50) NOT NULL,
        priority VARCHAR(50) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS system_settings (
        id SERIAL PRIMARY KEY,
        database_url VARCHAR(255),
        openai_api_key VARCHAR(255),
        twilio_account_sid VARCHAR(255),
        twilio_auth_token VARCHAR(255),
        twilio_phone_number VARCHAR(20),
        mpesa_consumer_key VARCHAR(255),
        mpesa_consumer_secret VARCHAR(255),
        mpesa_shortcode VARCHAR(20),
        mpesa_passkey VARCHAR(255),
        base_url VARCHAR(255)
      );

      CREATE TABLE IF NOT EXISTS whatsapp_messages (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(50) NOT NULL,
        content TEXT,
        type VARCHAR(50) NOT NULL,
        timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS employees (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        department VARCHAR(255) NOT NULL,
        position VARCHAR(255) NOT NULL,
        hire_date DATE NOT NULL,
        salary DECIMAL(10, 2) NOT NULL
      );

      CREATE TABLE IF NOT EXISTS leave_requests (
        id SERIAL PRIMARY KEY,
        employee_id VARCHAR(50) NOT NULL,
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        leave_type VARCHAR(50) NOT NULL,
        status VARCHAR(50) NOT NULL
      );
    `)
    console.log("Database schema initialized successfully")
  } catch (error) {
    console.error("Error initializing database schema:", error)
  } finally {
    client.release()
  }
}

export default initDatabase

