import { Server } from "ws"
import { createServer } from "http"
import { parse } from "url"
import { saveIoTData } from "./iot-data-handler"

const server = createServer()
const wss = new Server({ noServer: true })

wss.on("connection", (ws) => {
  console.log("New IoT device connected")

  ws.on("message", async (message) => {
    try {
      const data = JSON.parse(message.toString())
      await saveIoTData(data)
      console.log("Received and saved IoT data:", data)
    } catch (error) {
      console.error("Error processing IoT data:", error)
    }
  })

  ws.on("close", () => {
    console.log("IoT device disconnected")
  })
})

server.on("upgrade", (request, socket, head) => {
  const { pathname } = parse(request.url!)

  if (pathname === "/iot") {
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit("connection", ws, request)
    })
  } else {
    socket.destroy()
  }
})

export function startWebSocketServer(port: number) {
  server.listen(port, () => {
    console.log(`WebSocket server is running on port ${port}`)
  })
}

