import pool from "@/lib/db"

interface IoTData {
  deviceId: string
  sensorType: string
  value: number
  timestamp: string
}

export async function saveIoTData(data: IoTData) {
  const client = await pool.connect()
  try {
    await client.query("INSERT INTO iot_data (device_id, sensor_type, value, timestamp) VALUES ($1, $2, $3, $4)", [
      data.deviceId,
      data.sensorType,
      data.value,
      data.timestamp,
    ])
  } finally {
    client.release()
  }
}

