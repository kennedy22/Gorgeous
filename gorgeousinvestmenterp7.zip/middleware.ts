import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { analyzeError, optimizePerformance } from "./lib/utils/ai-monitor"

export async function middleware(request: NextRequest) {
  const startTime = Date.now()

  try {
    const response = await NextResponse.next()

    // Performance monitoring
    const endTime = Date.now()
    const duration = endTime - startTime
    const metrics = {
      duration,
      url: request.url,
      method: request.method,
    }

    if (duration > 1000) {
      // If request takes more than 1 second
      const optimizationSuggestion = await optimizePerformance(metrics)
      console.log("Performance optimization suggestion:", optimizationSuggestion)
    }

    return response
  } catch (error) {
    console.error("Error in middleware:", error)

    // AI-powered error analysis
    const errorAnalysis = await analyzeError(error as Error)
    console.log("AI Error Analysis:", errorAnalysis)

    // You might want to send this error analysis to a monitoring service or log it

    return new NextResponse(JSON.stringify({ success: false, message: "An error occurred", errorId: Date.now() }), {
      status: 500,
      headers: { "content-type": "application/json" },
    })
  }
}

export const config = {
  matcher: "/api/:path*",
}

