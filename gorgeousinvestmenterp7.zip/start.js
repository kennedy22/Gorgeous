const { exec } = require("child_process")
const path = require("path")

// Function to start the Next.js server
function startNextServer() {
  console.log("Starting Next.js server...")
  const nextStart = exec("npm run start", (error, stdout, stderr) => {
    if (error) {
      console.error(`Error starting Next.js server: ${error}`)
      return
    }
    console.log(`Next.js server output: ${stdout}`)
    console.error(`Next.js server errors: ${stderr}`)
  })

  nextStart.stdout.on("data", (data) => {
    console.log(`Next.js: ${data}`)
    if (data.includes("started server on")) {
      console.log("Next.js server is ready. Opening in default browser...")
      openBrowser()
    }
  })
}

// Function to open the default browser
function openBrowser() {
  const url = "http://localhost:3000"
  let command

  switch (process.platform) {
    case "darwin":
      command = `open ${url}`
      break
    case "win32":
      command = `start ${url}`
      break
    default:
      command = `xdg-open ${url}`
  }

  exec(command, (error) => {
    if (error) {
      console.error(`Failed to open browser: ${error}`)
    }
  })
}

// Start the application
startNextServer()

