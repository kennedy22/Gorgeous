import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import pool from "@/lib/db"

export async function apiAuth(request: NextRequest) {
  const apiKey = request.headers.get("X-API-Key")

  if (!apiKey) {
    return NextResponse.json({ error: "API key is required" }, { status: 401 })
  }

  try {
    const client = await pool.connect()
    const result = await client.query("SELECT * FROM api_keys WHERE key = $1", [apiKey])
    client.release()

    if (result.rows.length === 0) {
      return NextResponse.json({ error: "Invalid API key" }, { status: 401 })
    }

    // API key is valid, continue to the API route
    return NextResponse.next()
  } catch (error) {
    console.error("Error validating API key:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

