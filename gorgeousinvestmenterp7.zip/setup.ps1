# Setup script for Gorgeous Investment ERP

# Function to check if a command is available
function Test-Command($command) {
    $oldPreference = $ErrorActionPreference
    $ErrorActionPreference = 'stop'
    try { if (Get-Command $command) { return $true } }
    catch { return $false }
    finally { $ErrorActionPreference = $oldPreference }
}

# Check and install Chocolatey (package manager for Windows)
if (!(Test-Command choco)) {
    Write-Host "Installing Chocolatey..."
    Set-ExecutionPolicy Bypass -Scope Process -Force
    [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072
    Invoke-Expression ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))
}

# Install or update PostgreSQL
if (!(Test-Command psql)) {
    Write-Host "Installing PostgreSQL 17..."
    choco install postgresql17 --params '/Password:root' -y
} else {
    Write-Host "Updating PostgreSQL..."
    choco upgrade postgresql17 -y
}

# Install or update Node.js
if (!(Test-Command node)) {
    Write-Host "Installing Node.js..."
    choco install nodejs-lts -y
} else {
    Write-Host "Updating Node.js..."
    choco upgrade nodejs-lts -y
}

# Install or update Python
if (!(Test-Command python)) {
    Write-Host "Installing Python..."
    choco install python --version=3.9.0 -y
} else {
    Write-Host "Updating Python..."
    choco upgrade python --version=3.9.0 -y
}

# Create the PostgreSQL database for the ERP
$env:PGPASSWORD = "root"
$dbname = "gorgeous_investment_erp"
$dbuser = "erp_user"
$dbpassword = "erp_password"

Write-Host "Creating PostgreSQL database and user..."
psql -U postgres -c "CREATE DATABASE $dbname;"
psql -U postgres -c "CREATE USER $dbuser WITH ENCRYPTED PASSWORD '$dbpassword';"
psql -U postgres -c "GRANT ALL PRIVILEGES ON DATABASE $dbname TO $dbuser;"

# Install project dependencies
Write-Host "Installing project dependencies..."
npm install

# Initialize the database
Write-Host "Initializing the database..."
node init-db.js

Write-Host "Setup completed successfully!"

