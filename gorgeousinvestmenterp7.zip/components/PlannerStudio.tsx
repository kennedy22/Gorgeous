"use client"

import { useState } from "react"
import { Canvas } from "@react-three/fiber"
import { OrbitControls, useGLTF, Environment } from "@react-three/drei"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { HexColorPicker } from "react-colorful"
import { toast } from "@/components/ui/use-toast"

function Sofa({ color, width, depth, height }) {
  const { nodes, materials } = useGLTF("/assets/3d/sofa.glb")

  // Adjust the scale based on the dimensions
  const scale = [width / 100, height / 100, depth / 100]

  return (
    <group scale={scale}>
      <mesh geometry={nodes.Sofa.geometry}>
        <meshStandardMaterial color={color} />
      </mesh>
    </group>
  )
}

export function PlannerStudio() {
  const [sofaColor, setSofaColor] = useState("#b5a642")
  const [sofaWidth, setSofaWidth] = useState(200)
  const [sofaDepth, setSofaDepth] = useState(100)
  const [sofaHeight, setSofaHeight] = useState(80)
  const [fabricType, setFabricType] = useState("leather")
  const [customerId, setCustomerId] = useState("") // You'd typically get this from authentication

  const saveDesign = async () => {
    const design = {
      color: sofaColor,
      width: sofaWidth,
      depth: sofaDepth,
      height: sofaHeight,
      fabricType,
    }

    try {
      const response = await fetch("/api/planner-studio/designs", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ customerId, design }),
      })

      if (!response.ok) {
        throw new Error("Failed to save design")
      }

      toast({
        title: "Success",
        description: "Your sofa design has been saved.",
      })
    } catch (error) {
      console.error("Error saving design:", error)
      toast({
        title: "Error",
        description: "Failed to save your sofa design. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="w-full h-screen flex flex-col md:flex-row">
      <div className="w-full md:w-3/4 h-1/2 md:h-full">
        <Canvas camera={{ position: [0, 5, 5], fov: 50 }}>
          <ambientLight intensity={0.5} />
          <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} />
          <Sofa color={sofaColor} width={sofaWidth} depth={sofaDepth} height={sofaHeight} />
          <OrbitControls />
          <Environment preset="apartment" background />
        </Canvas>
      </div>
      <div className="w-full md:w-1/4 p-4 space-y-4 bg-gray-100">
        <h2 className="text-2xl font-bold mb-4">Customize Your Sofa</h2>
        <div>
          <label className="block mb-2">Color</label>
          <HexColorPicker color={sofaColor} onChange={setSofaColor} />
        </div>
        <div>
          <label className="block mb-2">Width (cm)</label>
          <Slider min={100} max={300} step={10} value={[sofaWidth]} onValueChange={(value) => setSofaWidth(value[0])} />
          <span>{sofaWidth} cm</span>
        </div>
        <div>
          <label className="block mb-2">Depth (cm)</label>
          <Slider min={50} max={150} step={10} value={[sofaDepth]} onValueChange={(value) => setSofaDepth(value[0])} />
          <span>{sofaDepth} cm</span>
        </div>
        <div>
          <label className="block mb-2">Height (cm)</label>
          <Slider min={60} max={120} step={5} value={[sofaHeight]} onValueChange={(value) => setSofaHeight(value[0])} />
          <span>{sofaHeight} cm</span>
        </div>
        <div>
          <label className="block mb-2">Fabric Type</label>
          <Select value={fabricType} onValueChange={setFabricType}>
            <SelectTrigger>
              <SelectValue placeholder="Select fabric type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="leather">Leather</SelectItem>
              <SelectItem value="cotton">Cotton</SelectItem>
              <SelectItem value="polyester">Polyester</SelectItem>
              <SelectItem value="velvet">Velvet</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="block mb-2">Customer ID</label>
          <input
            type="text"
            value={customerId}
            onChange={(e) => setCustomerId(e.target.value)}
            className="w-full p-2 border rounded"
            placeholder="Enter customer ID"
          />
        </div>
        <Button className="w-full" onClick={saveDesign}>
          Save Design
        </Button>
      </div>
    </div>
  )
}

