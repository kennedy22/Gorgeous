import type React from "react"
import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface DocumentCustomizerProps {
  onSave: (template: DocumentTemplate) => void
  initialTemplate?: DocumentTemplate
}

export interface DocumentTemplate {
  id?: string
  name: string
  content: string
  fontSize: number
  fontFamily: string
  headerImage?: string
  footerText: string
}

export const DocumentCustomizer: React.FC<DocumentCustomizerProps> = ({ onSave, initialTemplate }) => {
  const [template, setTemplate] = useState<DocumentTemplate>(
    initialTemplate || {
      name: "",
      content: "",
      fontSize: 12,
      fontFamily: "Arial",
      footerText: "",
    },
  )

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setTemplate((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string) => (value: string) => {
    setTemplate((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSave(template)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Input name="name" value={template.name} onChange={handleChange} placeholder="Document Name" />
      <Textarea
        name="content"
        value={template.content}
        onChange={handleChange}
        placeholder="Document Content"
        rows={10}
      />
      <div className="flex space-x-4">
        <div className="flex-1">
          <label className="block text-sm font-medium text-gray-700">Font Size</label>
          <Input type="number" name="fontSize" value={template.fontSize} onChange={handleChange} min={8} max={24} />
        </div>
        <div className="flex-1">
          <label className="block text-sm font-medium text-gray-700">Font Family</label>
          <Select value={template.fontFamily} onValueChange={handleSelectChange("fontFamily")}>
            <SelectTrigger>
              <SelectValue placeholder="Select font family" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Arial">Arial</SelectItem>
              <SelectItem value="Helvetica">Helvetica</SelectItem>
              <SelectItem value="Times New Roman">Times New Roman</SelectItem>
              <SelectItem value="Courier">Courier</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <Input
        name="headerImage"
        value={template.headerImage || ""}
        onChange={handleChange}
        placeholder="Header Image URL"
      />
      <Input name="footerText" value={template.footerText} onChange={handleChange} placeholder="Footer Text" />
      <Button type="submit">Save Template</Button>
    </form>
  )
}

