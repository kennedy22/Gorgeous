"use client"

import { useState, useEffect } from "react"
import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  addEdge,
  removeElements,
  type Elements,
  type Connection,
  type Edge,
} from "react-flow-renderer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { toast } from "@/components/ui/use-toast"

interface Workflow {
  id: number
  name: string
  description: string
  definition: Elements
}

export default function WorkflowDesigner() {
  const [workflows, setWorkflows] = useState<Workflow[]>([])
  const [selectedWorkflow, setSelectedWorkflow] = useState<Workflow | null>(null)
  const [elements, setElements] = useState<Elements>([])
  const [newWorkflowName, setNewWorkflowName] = useState("")
  const [newWorkflowDescription, setNewWorkflowDescription] = useState("")

  useEffect(() => {
    fetchWorkflows()
  }, [])

  const fetchWorkflows = async () => {
    try {
      const response = await fetch("/api/workflows")
      if (!response.ok) throw new Error("Failed to fetch workflows")
      const data = await response.json()
      setWorkflows(data)
    } catch (error) {
      console.error("Error fetching workflows:", error)
      toast({
        title: "Error",
        description: "Failed to load workflows. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleWorkflowSelect = (workflowId: number) => {
    const workflow = workflows.find((w) => w.id === workflowId)
    if (workflow) {
      setSelectedWorkflow(workflow)
      setElements(workflow.definition)
    }
  }

  const onElementsRemove = (elementsToRemove: Elements) => {
    setElements((els) => removeElements(elementsToRemove, els))
  }

  const onConnect = (params: Connection | Edge) => {
    setElements((els) => addEdge(params, els))
  }

  const onElementsChange = (changedElements: Elements) => {
    setElements(changedElements)
  }

  const handleSaveWorkflow = async () => {
    if (!selectedWorkflow) return

    try {
      const response = await fetch(`/api/workflows/${selectedWorkflow.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...selectedWorkflow, definition: elements }),
      })
      if (!response.ok) throw new Error("Failed to save workflow")
      toast({
        title: "Success",
        description: "Workflow saved successfully.",
      })
    } catch (error) {
      console.error("Error saving workflow:", error)
      toast({
        title: "Error",
        description: "Failed to save workflow. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleCreateWorkflow = async () => {
    try {
      const response = await fetch("/api/workflows", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newWorkflowName, description: newWorkflowDescription }),
      })
      if (!response.ok) throw new Error("Failed to create workflow")
      const newWorkflow = await response.json()
      setWorkflows([...workflows, newWorkflow])
      setNewWorkflowName("")
      setNewWorkflowDescription("")
      toast({
        title: "Success",
        description: "New workflow created successfully.",
      })
    } catch (error) {
      console.error("Error creating workflow:", error)
      toast({
        title: "Error",
        description: "Failed to create workflow. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="flex h-screen">
      <div className="w-1/4 p-4 border-r">
        <h2 className="text-2xl font-bold mb-4">Workflows</h2>
        <div className="space-y-2 mb-4">
          <Input
            placeholder="Workflow Name"
            value={newWorkflowName}
            onChange={(e) => setNewWorkflowName(e.target.value)}
          />
          <Input
            placeholder="Workflow Description"
            value={newWorkflowDescription}
            onChange={(e) => setNewWorkflowDescription(e.target.value)}
          />
          <Button onClick={handleCreateWorkflow}>Create Workflow</Button>
        </div>
        <ul>
          {workflows.map((workflow) => (
            <li
              key={workflow.id}
              className="cursor-pointer p-2 hover:bg-gray-100"
              onClick={() => handleWorkflowSelect(workflow.id)}
            >
              {workflow.name}
            </li>
          ))}
        </ul>
      </div>
      <div className="w-3/4 p-4">
        {selectedWorkflow ? (
          <>
            <h2 className="text-2xl font-bold mb-4">{selectedWorkflow.name}</h2>
            <div className="h-[calc(100vh-8rem)]">
              <ReactFlow
                elements={elements}
                onElementsRemove={onElementsRemove}
                onConnect={onConnect}
                onElementsChange={onElementsChange}
                deleteKeyCode={46}
              >
                <Controls />
                <MiniMap />
                <Background color="#aaa" gap={16} />
              </ReactFlow>
            </div>
            <Button className="mt-4" onClick={handleSaveWorkflow}>
              Save Workflow
            </Button>
          </>
        ) : (
          <p>Select a workflow to edit</p>
        )}
      </div>
    </div>
  )
}

