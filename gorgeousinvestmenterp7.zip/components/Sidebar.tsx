"use client"

import Link from "next/link"
import { Settings, Menu, Cog } from "lucide-react"
import { useState } from "react"
import { Button } from "@/components/ui/button"

const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(false)

  const toggleSidebar = () => setIsOpen(!isOpen)

  return (
    <>
      <Button variant="ghost" className="md:hidden fixed top-4 left-4 z-50" onClick={toggleSidebar}>
        <Menu size={24} />
      </Button>
      <div
        className={`bg-gray-800 text-white p-4 md:w-64 md:static md:h-screen fixed inset-y-0 left-0 transform ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        } transition-transform duration-200 ease-in-out md:translate-x-0 z-40`}
      >
        <h1 className="text-2xl font-bold mb-8">Gorgeous Investment</h1>
        <nav>
          <ul className="space-y-2">
            {/* Existing menu items... */}
            <li>
              <Link
                href="/advanced-manufacturing"
                className="flex items-center space-x-2 hover:text-gray-300"
                onClick={() => setIsOpen(false)}
              >
                <Cog size={20} />
                <span>Advanced Manufacturing</span>
              </Link>
            </li>
            <li>
              <Link
                href="/settings"
                className="flex items-center space-x-2 hover:text-gray-300"
                onClick={() => setIsOpen(false)}
              >
                <Settings size={20} />
                <span>Settings</span>
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </>
  )
}

export default Sidebar

