"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface Supplier {
  id: number
  name: string
  contactPerson: string
  email: string
  phone: string
}

export default function SupplierManagement() {
  const [suppliers, setSuppliers] = useState<Supplier[]>([])
  const [newSupplier, setNewSupplier] = useState<Partial<Supplier>>({})

  useEffect(() => {
    fetchSuppliers()
  }, [])

  const fetchSuppliers = async () => {
    try {
      const response = await fetch("/api/supply-chain/suppliers")
      if (!response.ok) throw new Error("Failed to fetch suppliers")
      const data = await response.json()
      setSuppliers(data)
    } catch (error) {
      console.error("Error fetching suppliers:", error)
      toast({
        title: "Error",
        description: "Failed to load suppliers. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNewSupplier((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/supply-chain/suppliers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newSupplier),
      })
      if (!response.ok) throw new Error("Failed to create supplier")
      await fetchSuppliers()
      setNewSupplier({})
      toast({
        title: "Success",
        description: "Supplier created successfully.",
      })
    } catch (error) {
      console.error("Error creating supplier:", error)
      toast({
        title: "Error",
        description: "Failed to create supplier. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Supplier Management</h2>
      <form onSubmit={handleSubmit} className="space-y-2">
        <Input
          name="name"
          value={newSupplier.name || ""}
          onChange={handleInputChange}
          placeholder="Supplier Name"
          required
        />
        <Input
          name="contactPerson"
          value={newSupplier.contactPerson || ""}
          onChange={handleInputChange}
          placeholder="Contact Person"
          required
        />
        <Input
          name="email"
          type="email"
          value={newSupplier.email || ""}
          onChange={handleInputChange}
          placeholder="Email"
          required
        />
        <Input name="phone" value={newSupplier.phone || ""} onChange={handleInputChange} placeholder="Phone" required />
        <Button type="submit">Add Supplier</Button>
      </form>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Contact Person</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Phone</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {suppliers.map((supplier) => (
            <TableRow key={supplier.id}>
              <TableCell>{supplier.name}</TableCell>
              <TableCell>{supplier.contactPerson}</TableCell>
              <TableCell>{supplier.email}</TableCell>
              <TableCell>{supplier.phone}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

