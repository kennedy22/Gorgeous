"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface InventoryItem {
  id: number
  productName: string
  stockQuantity: number
  reorderPoint: number
}

export default function InventoryManagement() {
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>([])
  const [newQuantity, setNewQuantity] = useState<{ [key: number]: number }>({})

  useEffect(() => {
    fetchInventory()
  }, [])

  const fetchInventory = async () => {
    try {
      const response = await fetch("/api/e-commerce/inventory")
      if (!response.ok) throw new Error("Failed to fetch inventory")
      const data = await response.json()
      setInventoryItems(data)
    } catch (error) {
      console.error("Error fetching inventory:", error)
      toast({
        title: "Error",
        description: "Failed to load inventory. Please try again.",
        variant: "destructive",
      })
    }
  }

  const updateInventory = async (productId: number) => {
    try {
      const response = await fetch(`/api/e-commerce/inventory/${productId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ quantity: newQuantity[productId] }),
      })
      if (!response.ok) throw new Error("Failed to update inventory")
      await fetchInventory()
      setNewQuantity((prev) => ({ ...prev, [productId]: 0 }))
      toast({
        title: "Success",
        description: "Inventory updated successfully.",
      })
    } catch (error) {
      console.error("Error updating inventory:", error)
      toast({
        title: "Error",
        description: "Failed to update inventory. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleQuantityChange = (productId: number, value: string) => {
    setNewQuantity((prev) => ({ ...prev, [productId]: Number.parseInt(value) || 0 }))
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Inventory Management</h2>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Product Name</TableHead>
            <TableHead>Current Stock</TableHead>
            <TableHead>Reorder Point</TableHead>
            <TableHead>Update Stock</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {inventoryItems.map((item) => (
            <TableRow key={item.id}>
              <TableCell>{item.productName}</TableCell>
              <TableCell>{item.stockQuantity}</TableCell>
              <TableCell>{item.reorderPoint}</TableCell>
              <TableCell>
                <Input
                  type="number"
                  value={newQuantity[item.id] || ""}
                  onChange={(e) => handleQuantityChange(item.id, e.target.value)}
                  placeholder="New quantity"
                />
              </TableCell>
              <TableCell>
                <Button onClick={() => updateInventory(item.id)}>Update</Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

