"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

interface ConfigContextType {
  isConfigured: boolean
  setIsConfigured: React.Dispatch<React.SetStateAction<boolean>>
  saveConfig: (config: Record<string, string>) => Promise<void>
  getConfig: () => Promise<Record<string, string>>
}

const ConfigContext = createContext<ConfigContextType | undefined>(undefined)

export function ConfigProvider({ children }: { children: React.ReactNode }) {
  const [isConfigured, setIsConfigured] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    checkConfig()
  }, [])

  const checkConfig = async () => {
    try {
      const config = await window.electron.getConfig()
      setIsConfigured(!!config && Object.keys(config).length > 0)
    } catch (error) {
      console.error("Failed to check config:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const saveConfig = async (config: Record<string, string>) => {
    try {
      await window.electron.saveConfig(config)
      setIsConfigured(true)
    } catch (error) {
      console.error("Failed to save config:", error)
      throw error
    }
  }

  const getConfig = async () => {
    try {
      return await window.electron.getConfig()
    } catch (error) {
      console.error("Failed to get config:", error)
      throw error
    }
  }

  if (isLoading) {
    return <div>Loading...</div>
  }

  return (
    <ConfigContext.Provider value={{ isConfigured, setIsConfigured, saveConfig, getConfig }}>
      {children}
    </ConfigContext.Provider>
  )
}

export function useConfig() {
  const context = useContext(ConfigContext)
  if (context === undefined) {
    throw new Error("useConfig must be used within a ConfigProvider")
  }
  return context
}

