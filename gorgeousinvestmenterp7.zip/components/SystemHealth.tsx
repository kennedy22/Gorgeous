"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Activity, Cpu, Server } from "lucide-react"
import { toast } from "@/components/ui/use-toast"

interface Metrics {
  cpuUsage: number
  memoryUsage: number
  responseTime: number
}

const defaultMetrics: Metrics = {
  cpuUsage: 0,
  memoryUsage: 0,
  responseTime: 0,
}

export function SystemHealth() {
  const [metrics, setMetrics] = useState<Metrics>(defaultMetrics)

  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const response = await fetch("/api/system/metrics")
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`)
        }
        const data = await response.json()
        setMetrics(data)
      } catch (error) {
        console.error("Failed to fetch system metrics:", error)
        toast({
          title: "Error",
          description: "Failed to fetch system metrics. Using default values.",
          variant: "destructive",
        })
        setMetrics(defaultMetrics)
      }
    }

    fetchMetrics()
    const interval = setInterval(fetchMetrics, 60000) // Update every minute

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">CPU Usage</CardTitle>
          <Cpu className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{metrics.cpuUsage.toFixed(2)}%</div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Memory Usage</CardTitle>
          <Server className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{metrics.memoryUsage.toFixed(2)}%</div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Avg Response Time</CardTitle>
          <Activity className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{metrics.responseTime.toFixed(2)}ms</div>
        </CardContent>
      </Card>
    </div>
  )
}

