"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { toast } from "@/components/ui/use-toast"
import { useConfig } from "./ConfigProvider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface ConfigField {
  key: string
  label: string
  type: string
  description: string
}

const configFields: ConfigField[] = [
  {
    key: "POSTGRES_URL",
    label: "PostgreSQL Connection URL",
    type: "text",
    description: "The connection URL for your PostgreSQL database.",
  },
  {
    key: "POSTGRES_USER",
    label: "PostgreSQL User",
    type: "text",
    description: "The username for your PostgreSQL database.",
  },
  {
    key: "POSTGRES_PASSWORD",
    label: "PostgreSQL Password",
    type: "password",
    description: "The password for your PostgreSQL database.",
  },
  {
    key: "POSTGRES_DB",
    label: "PostgreSQL Database Name",
    type: "text",
    description: "The name of your PostgreSQL database.",
  },
  {
    key: "JWT_SECRET_KEY",
    label: "JWT Secret Key",
    type: "password",
    description: "A secret key used for JWT token generation.",
  },
  {
    key: "OPENAI_API_KEY",
    label: "OpenAI API Key",
    type: "password",
    description: "Your OpenAI API key for AI-powered features.",
  },
  {
    key: "TWILIO_ACCOUNT_SID",
    label: "Twilio Account SID",
    type: "text",
    description: "Your Twilio Account SID for SMS and WhatsApp notifications.",
  },
  {
    key: "TWILIO_AUTH_TOKEN",
    label: "Twilio Auth Token",
    type: "password",
    description: "Your Twilio Auth Token for SMS and WhatsApp notifications.",
  },
  {
    key: "TWILIO_PHONE_NUMBER",
    label: "Twilio Phone Number",
    type: "text",
    description: "Your Twilio phone number for sending notifications.",
  },
  {
    key: "MPESA_CONSUMER_KEY",
    label: "M-Pesa Consumer Key",
    type: "password",
    description: "Your M-Pesa Consumer Key for payment integration.",
  },
  {
    key: "MPESA_CONSUMER_SECRET",
    label: "M-Pesa Consumer Secret",
    type: "password",
    description: "Your M-Pesa Consumer Secret for payment integration.",
  },
  {
    key: "MPESA_SHORTCODE",
    label: "M-Pesa Shortcode",
    type: "text",
    description: "Your M-Pesa Shortcode for payment integration.",
  },
  {
    key: "MPESA_PASSKEY",
    label: "M-Pesa Passkey",
    type: "password",
    description: "Your M-Pesa Passkey for payment integration.",
  },
  { key: "BASE_URL", label: "Base URL", type: "text", description: "The base URL of your application." },
  {
    key: "NEXTAUTH_SECRET",
    label: "NextAuth Secret",
    type: "password",
    description: "A secret key used by NextAuth for session encryption.",
  },
]

export function SetupWizard() {
  const { saveConfig } = useConfig()
  const [config, setConfig] = useState<Record<string, string>>(
    Object.fromEntries(configFields.map((field) => [field.key, ""])),
  )

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setConfig((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await saveConfig(config)
      toast({ title: "Success", description: "System configured successfully. Please restart the application." })
    } catch (error) {
      toast({ title: "Error", description: "Failed to configure system. Please try again.", variant: "destructive" })
    }
  }

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-6">Gorgeous Investment ERP Setup</h1>
      <form onSubmit={handleSubmit} className="space-y-6">
        {configFields.map((field) => (
          <Card key={field.key}>
            <CardHeader>
              <CardTitle>{field.label}</CardTitle>
              <CardDescription>{field.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <Input
                type={field.type}
                name={field.key}
                value={config[field.key]}
                onChange={handleInputChange}
                placeholder={field.label}
                required
              />
            </CardContent>
          </Card>
        ))}
        <Button type="submit" className="w-full">
          Complete Setup
        </Button>
      </form>
    </div>
  )
}

