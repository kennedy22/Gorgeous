"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"
import { Gantt, type Task, ViewMode } from "gantt-task-react"
import "gantt-task-react/dist/index.css"

interface Project {
  id: number
  name: string
  startDate: string
  endDate: string
  status: string
}

export default function ProjectManagement() {
  const [projects, setProjects] = useState<Project[]>([])
  const [newProject, setNewProject] = useState<Partial<Project>>({})
  const [tasks, setTasks] = useState<Task[]>([])

  useEffect(() => {
    fetchProjects()
    fetchTasks()
  }, [])

  const fetchProjects = async () => {
    try {
      const response = await fetch("/api/project/projects")
      if (!response.ok) throw new Error("Failed to fetch projects")
      const data = await response.json()
      setProjects(data)
    } catch (error) {
      console.error("Error fetching projects:", error)
      toast({
        title: "Error",
        description: "Failed to load projects. Please try again.",
        variant: "destructive",
      })
    }
  }

  const fetchTasks = async () => {
    try {
      const response = await fetch("/api/project/tasks")
      if (!response.ok) throw new Error("Failed to fetch tasks")
      const data = await response.json()
      setTasks(data)
    } catch (error) {
      console.error("Error fetching tasks:", error)
      toast({
        title: "Error",
        description: "Failed to load tasks. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNewProject((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/project/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newProject),
      })
      if (!response.ok) throw new Error("Failed to create project")
      await fetchProjects()
      setNewProject({})
      toast({
        title: "Success",
        description: "Project created successfully.",
      })
    } catch (error) {
      console.error("Error creating project:", error)
      toast({
        title: "Error",
        description: "Failed to create project. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Project Management</h2>
      <form onSubmit={handleSubmit} className="space-y-2">
        <Input
          name="name"
          value={newProject.name || ""}
          onChange={handleInputChange}
          placeholder="Project Name"
          required
        />
        <Input name="startDate" type="date" value={newProject.startDate || ""} onChange={handleInputChange} required />
        <Input name="endDate" type="date" value={newProject.endDate || ""} onChange={handleInputChange} required />
        <Button type="submit">Create Project</Button>
      </form>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Start Date</TableHead>
            <TableHead>End Date</TableHead>
            <TableHead>Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {projects.map((project) => (
            <TableRow key={project.id}>
              <TableCell>{project.name}</TableCell>
              <TableCell>{project.startDate}</TableCell>
              <TableCell>{project.endDate}</TableCell>
              <TableCell>{project.status}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <h3 className="text-xl font-bold mt-8">Gantt Chart</h3>
      <Gantt tasks={tasks} viewMode={ViewMode.Month} />
    </div>
  )
}

