"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { toast } from "@/components/ui/use-toast"

type Message = {
  id: string
  userId: string
  userName: string
  content: string
  type: "received" | "sold" | "payment"
  timestamp: string
}

export function WhatsAppFeed() {
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [messageType, setMessageType] = useState<"received" | "sold" | "payment">("received")

  useEffect(() => {
    fetchMessages()
  }, [])

  const fetchMessages = async () => {
    try {
      const response = await fetch("/api/whatsapp-messages")
      if (!response.ok) throw new Error("Failed to fetch messages")
      const data = await response.json()
      setMessages(data)
    } catch (error) {
      console.error("Error fetching messages:", error)
      toast({
        title: "Error",
        description: "Failed to load messages. Please try again.",
        variant: "destructive",
      })
    }
  }

  const sendMessage = async () => {
    try {
      const response = await fetch("/api/whatsapp-messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content: newMessage,
          type: messageType,
        }),
      })
      if (!response.ok) throw new Error("Failed to send message")
      setNewMessage("")
      fetchMessages()
      toast({
        title: "Success",
        description: "Message sent successfully.",
      })
    } catch (error) {
      console.error("Error sending message:", error)
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">WhatsApp Feed</h2>
      <div className="border rounded-lg p-4 h-96 overflow-y-auto space-y-2">
        {messages.map((message) => (
          <div key={message.id} className="p-2 bg-gray-100 rounded">
            <p className="font-bold">{message.userName}</p>
            <p>{message.content}</p>
            <p className="text-sm text-gray-500">
              {message.type} - {new Date(message.timestamp).toLocaleString()}
            </p>
          </div>
        ))}
      </div>
      <div className="flex space-x-2">
        <Select value={messageType} onValueChange={(value: "received" | "sold" | "payment") => setMessageType(value)}>
          <SelectTrigger>
            <SelectValue placeholder="Message Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="received">Product Received</SelectItem>
            <SelectItem value="sold">Product Sold</SelectItem>
            <SelectItem value="payment">Payment Received</SelectItem>
          </SelectContent>
        </Select>
        <Input value={newMessage} onChange={(e) => setNewMessage(e.target.value)} placeholder="Type your message..." />
        <Button onClick={sendMessage}>Send</Button>
      </div>
    </div>
  )
}

