"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface MRPItem {
  id: number
  productName: string
  requiredQuantity: number
  availableQuantity: number
  orderQuantity: number
}

export default function MRPComponent() {
  const [mrpItems, setMrpItems] = useState<MRPItem[]>([])
  const [productionOrder, setProductionOrder] = useState("")
  const [quantity, setQuantity] = useState("")

  useEffect(() => {
    fetchMRPData()
  }, [])

  const fetchMRPData = async () => {
    try {
      const response = await fetch("/api/production/mrp")
      if (!response.ok) throw new Error("Failed to fetch MRP data")
      const data = await response.json()
      setMrpItems(data)
    } catch (error) {
      console.error("Error fetching MRP data:", error)
      toast({
        title: "Error",
        description: "Failed to load MRP data. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleRunMRP = async () => {
    try {
      const response = await fetch("/api/production/mrp/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productionOrder, quantity: Number.parseInt(quantity) }),
      })
      if (!response.ok) throw new Error("Failed to run MRP")
      await fetchMRPData()
      toast({
        title: "Success",
        description: "MRP calculation completed successfully.",
      })
    } catch (error) {
      console.error("Error running MRP:", error)
      toast({
        title: "Error",
        description: "Failed to run MRP. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex space-x-2">
        <Input
          placeholder="Production Order"
          value={productionOrder}
          onChange={(e) => setProductionOrder(e.target.value)}
        />
        <Input type="number" placeholder="Quantity" value={quantity} onChange={(e) => setQuantity(e.target.value)} />
        <Button onClick={handleRunMRP}>Run MRP</Button>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Product</TableHead>
            <TableHead>Required Quantity</TableHead>
            <TableHead>Available Quantity</TableHead>
            <TableHead>Order Quantity</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {mrpItems.map((item) => (
            <TableRow key={item.id}>
              <TableCell>{item.productName}</TableCell>
              <TableCell>{item.requiredQuantity}</TableCell>
              <TableCell>{item.availableQuantity}</TableCell>
              <TableCell>{item.orderQuantity}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

