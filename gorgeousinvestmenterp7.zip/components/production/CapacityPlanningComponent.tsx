"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface CapacityPlan {
  id: number
  resourceName: string
  availableCapacity: number
  requiredCapacity: number
  utilizationRate: number
}

export default function CapacityPlanningComponent() {
  const [capacityPlans, setCapacityPlans] = useState<CapacityPlan[]>([])
  const [startDate, setStartDate] = useState("")
  const [endDate, setEndDate] = useState("")

  useEffect(() => {
    fetchCapacityPlans()
  }, [])

  const fetchCapacityPlans = async () => {
    try {
      const response = await fetch("/api/production/capacity-planning")
      if (!response.ok) throw new Error("Failed to fetch capacity plans")
      const data = await response.json()
      setCapacityPlans(data)
    } catch (error) {
      console.error("Error fetching capacity plans:", error)
      toast({
        title: "Error",
        description: "Failed to load capacity plans. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleRunCapacityPlanning = async () => {
    try {
      const response = await fetch("/api/production/capacity-planning/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ startDate, endDate }),
      })
      if (!response.ok) throw new Error("Failed to run capacity planning")
      await fetchCapacityPlans()
      toast({
        title: "Success",
        description: "Capacity planning completed successfully.",
      })
    } catch (error) {
      console.error("Error running capacity planning:", error)
      toast({
        title: "Error",
        description: "Failed to run capacity planning. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex space-x-2">
        <Input type="date" placeholder="Start Date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
        <Input type="date" placeholder="End Date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
        <Button onClick={handleRunCapacityPlanning}>Run Capacity Planning</Button>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Resource</TableHead>
            <TableHead>Available Capacity</TableHead>
            <TableHead>Required Capacity</TableHead>
            <TableHead>Utilization Rate</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {capacityPlans.map((plan) => (
            <TableRow key={plan.id}>
              <TableCell>{plan.resourceName}</TableCell>
              <TableCell>{plan.availableCapacity}</TableCell>
              <TableCell>{plan.requiredCapacity}</TableCell>
              <TableCell>{plan.utilizationRate.toFixed(2)}%</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

