"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface PerformanceEvaluation {
  id: number
  employeeName: string
  evaluatorName: string
  evaluationDate: string
  overallRating: number
  comments: string
}

export default function PerformanceEvaluations() {
  const [evaluations, setEvaluations] = useState<PerformanceEvaluation[]>([])
  const [newEvaluation, setNewEvaluation] = useState<Partial<PerformanceEvaluation>>({})
  const [employees, setEmployees] = useState<{ id: string; name: string }[]>([])

  useEffect(() => {
    fetchEvaluations()
    fetchEmployees()
  }, [])

  const fetchEvaluations = async () => {
    try {
      const response = await fetch("/api/hr/performance-evaluations")
      if (!response.ok) throw new Error("Failed to fetch evaluations")
      const data = await response.json()
      setEvaluations(data)
    } catch (error) {
      console.error("Error fetching evaluations:", error)
      toast({
        title: "Error",
        description: "Failed to load performance evaluations. Please try again.",
        variant: "destructive",
      })
    }
  }

  const fetchEmployees = async () => {
    try {
      const response = await fetch("/api/hr/employees")
      if (!response.ok) throw new Error("Failed to fetch employees")
      const data = await response.json()
      setEmployees(data)
    } catch (error) {
      console.error("Error fetching employees:", error)
      toast({
        title: "Error",
        description: "Failed to load employees. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setNewEvaluation((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string) => (value: string) => {
    setNewEvaluation((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/hr/performance-evaluations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newEvaluation),
      })
      if (!response.ok) throw new Error("Failed to submit evaluation")
      await fetchEvaluations()
      setNewEvaluation({})
      toast({
        title: "Success",
        description: "Performance evaluation submitted successfully.",
      })
    } catch (error) {
      console.error("Error submitting evaluation:", error)
      toast({
        title: "Error",
        description: "Failed to submit performance evaluation. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Performance Evaluations</h2>
      <form onSubmit={handleSubmit} className="space-y-2">
        <Select value={newEvaluation.employeeName} onValueChange={handleSelectChange("employeeName")}>
          <SelectTrigger>
            <SelectValue placeholder="Select employee" />
          </SelectTrigger>
          <SelectContent>
            {employees.map((employee) => (
              <SelectItem key={employee.id} value={employee.name}>
                {employee.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Input
          name="evaluationDate"
          type="date"
          value={newEvaluation.evaluationDate || ""}
          onChange={handleInputChange}
          required
        />
        <Input
          name="overallRating"
          type="number"
          min="1"
          max="5"
          value={newEvaluation.overallRating || ""}
          onChange={handleInputChange}
          placeholder="Overall Rating (1-5)"
          required
        />
        <Textarea
          name="comments"
          value={newEvaluation.comments || ""}
          onChange={handleInputChange}
          placeholder="Comments"
          required
        />
        <Button type="submit">Submit Evaluation</Button>
      </form>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Employee</TableHead>
            <TableHead>Evaluator</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Overall Rating</TableHead>
            <TableHead>Comments</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {evaluations.map((evaluation) => (
            <TableRow key={evaluation.id}>
              <TableCell>{evaluation.employeeName}</TableCell>
              <TableCell>{evaluation.evaluatorName}</TableCell>
              <TableCell>{evaluation.evaluationDate}</TableCell>
              <TableCell>{evaluation.overallRating}</TableCell>
              <TableCell>{evaluation.comments}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

