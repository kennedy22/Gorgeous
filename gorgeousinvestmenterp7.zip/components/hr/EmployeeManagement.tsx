"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface Employee {
  id: number
  name: string
  department: string
  position: string
  hireDate: string
  salary: number
}

export default function EmployeeManagement() {
  const [employees, setEmployees] = useState<Employee[]>([])
  const [newEmployee, setNewEmployee] = useState<Partial<Employee>>({})

  useEffect(() => {
    fetchEmployees()
  }, [])

  const fetchEmployees = async () => {
    try {
      const response = await fetch("/api/hr/employees")
      if (!response.ok) throw new Error("Failed to fetch employees")
      const data = await response.json()
      setEmployees(data)
    } catch (error) {
      console.error("Error fetching employees:", error)
      toast({
        title: "Error",
        description: "Failed to load employees. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNewEmployee((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/hr/employees", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newEmployee),
      })
      if (!response.ok) throw new Error("Failed to add employee")
      await fetchEmployees()
      setNewEmployee({})
      toast({
        title: "Success",
        description: "Employee added successfully.",
      })
    } catch (error) {
      console.error("Error adding employee:", error)
      toast({
        title: "Error",
        description: "Failed to add employee. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Employee Management</h2>
      <form onSubmit={handleSubmit} className="space-y-2">
        <Input
          name="name"
          value={newEmployee.name || ""}
          onChange={handleInputChange}
          placeholder="Employee Name"
          required
        />
        <Input
          name="department"
          value={newEmployee.department || ""}
          onChange={handleInputChange}
          placeholder="Department"
          required
        />
        <Input
          name="position"
          value={newEmployee.position || ""}
          onChange={handleInputChange}
          placeholder="Position"
          required
        />
        <Input name="hireDate" type="date" value={newEmployee.hireDate || ""} onChange={handleInputChange} required />
        <Input
          name="salary"
          type="number"
          value={newEmployee.salary || ""}
          onChange={handleInputChange}
          placeholder="Salary"
          required
        />
        <Button type="submit">Add Employee</Button>
      </form>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Department</TableHead>
            <TableHead>Position</TableHead>
            <TableHead>Hire Date</TableHead>
            <TableHead>Salary</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {employees.map((employee) => (
            <TableRow key={employee.id}>
              <TableCell>{employee.name}</TableCell>
              <TableCell>{employee.department}</TableCell>
              <TableCell>{employee.position}</TableCell>
              <TableCell>{employee.hireDate}</TableCell>
              <TableCell>{employee.salary}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

