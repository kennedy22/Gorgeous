"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface TimeEntry {
  id: number
  employeeName: string
  clockIn: string
  clockOut: string
}

export default function TimeAttendance() {
  const [timeEntries, setTimeEntries] = useState<TimeEntry[]>([])

  useEffect(() => {
    fetchTimeEntries()
  }, [])

  const fetchTimeEntries = async () => {
    try {
      const response = await fetch("/api/hr/time-entries")
      if (!response.ok) throw new Error("Failed to fetch time entries")
      const data = await response.json()
      setTimeEntries(data)
    } catch (error) {
      console.error("Error fetching time entries:", error)
      toast({
        title: "Error",
        description: "Failed to load time entries. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleClockIn = async () => {
    try {
      const response = await fetch("/api/hr/time-entries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "clockIn" }),
      })
      if (!response.ok) throw new Error("Failed to clock in")
      await fetchTimeEntries()
      toast({
        title: "Success",
        description: "Clocked in successfully.",
      })
    } catch (error) {
      console.error("Error clocking in:", error)
      toast({
        title: "Error",
        description: "Failed to clock in. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleClockOut = async () => {
    try {
      const response = await fetch("/api/hr/time-entries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "clockOut" }),
      })
      if (!response.ok) throw new Error("Failed to clock out")
      await fetchTimeEntries()
      toast({
        title: "Success",
        description: "Clocked out successfully.",
      })
    } catch (error) {
      console.error("Error clocking out:", error)
      toast({
        title: "Error",
        description: "Failed to clock out. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Time & Attendance</h2>
      <div className="space-x-2">
        <Button onClick={handleClockIn}>Clock In</Button>
        <Button onClick={handleClockOut}>Clock Out</Button>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Employee</TableHead>
            <TableHead>Clock In</TableHead>
            <TableHead>Clock Out</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {timeEntries.map((entry) => (
            <TableRow key={entry.id}>
              <TableCell>{entry.employeeName}</TableCell>
              <TableCell>{entry.clockIn}</TableCell>
              <TableCell>{entry.clockOut || "Not clocked out"}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

