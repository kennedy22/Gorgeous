"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface JobOpening {
  id: number
  title: string
  department: string
  description: string
  requirements: string
  status: string
}

export default function Recruitment() {
  const [jobOpenings, setJobOpenings] = useState<JobOpening[]>([])
  const [newJobOpening, setNewJobOpening] = useState<Partial<JobOpening>>({})

  useEffect(() => {
    fetchJobOpenings()
  }, [])

  const fetchJobOpenings = async () => {
    try {
      const response = await fetch("/api/hr/job-openings")
      if (!response.ok) throw new Error("Failed to fetch job openings")
      const data = await response.json()
      setJobOpenings(data)
    } catch (error) {
      console.error("Error fetching job openings:", error)
      toast({
        title: "Error",
        description: "Failed to load job openings. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setNewJobOpening((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/hr/job-openings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newJobOpening),
      })
      if (!response.ok) throw new Error("Failed to create job opening")
      await fetchJobOpenings()
      setNewJobOpening({})
      toast({
        title: "Success",
        description: "Job opening created successfully.",
      })
    } catch (error) {
      console.error("Error creating job opening:", error)
      toast({
        title: "Error",
        description: "Failed to create job opening. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Recruitment</h2>
      <form onSubmit={handleSubmit} className="space-y-2">
        <Input
          name="title"
          value={newJobOpening.title || ""}
          onChange={handleInputChange}
          placeholder="Job Title"
          required
        />
        <Input
          name="department"
          value={newJobOpening.department || ""}
          onChange={handleInputChange}
          placeholder="Department"
          required
        />
        <Textarea
          name="description"
          value={newJobOpening.description || ""}
          onChange={handleInputChange}
          placeholder="Job Description"
          required
        />
        <Textarea
          name="requirements"
          value={newJobOpening.requirements || ""}
          onChange={handleInputChange}
          placeholder="Job Requirements"
          required
        />
        <Button type="submit">Create Job Opening</Button>
      </form>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Title</TableHead>
            <TableHead>Department</TableHead>
            <TableHead>Description</TableHead>
            <TableHead>Requirements</TableHead>
            <TableHead>Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {jobOpenings.map((job) => (
            <TableRow key={job.id}>
              <TableCell>{job.title}</TableCell>
              <TableCell>{job.department}</TableCell>
              <TableCell>{job.description}</TableCell>
              <TableCell>{job.requirements}</TableCell>
              <TableCell>{job.status}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

