"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface LeaveRequest {
  id: number
  employeeName: string
  startDate: string
  endDate: string
  leaveType: string
  status: string
}

export default function LeaveManagement() {
  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>([])
  const [newRequest, setNewRequest] = useState<Partial<LeaveRequest>>({})

  useEffect(() => {
    fetchLeaveRequests()
  }, [])

  const fetchLeaveRequests = async () => {
    try {
      const response = await fetch("/api/hr/leave-requests")
      if (!response.ok) throw new Error("Failed to fetch leave requests")
      const data = await response.json()
      setLeaveRequests(data)
    } catch (error) {
      console.error("Error fetching leave requests:", error)
      toast({
        title: "Error",
        description: "Failed to load leave requests. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNewRequest((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string) => (value: string) => {
    setNewRequest((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/hr/leave-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newRequest),
      })
      if (!response.ok) throw new Error("Failed to submit leave request")
      await fetchLeaveRequests()
      setNewRequest({})
      toast({
        title: "Success",
        description: "Leave request submitted successfully.",
      })
    } catch (error) {
      console.error("Error submitting leave request:", error)
      toast({
        title: "Error",
        description: "Failed to submit leave request. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Leave Management</h2>
      <form onSubmit={handleSubmit} className="space-y-2">
        <Input name="startDate" type="date" value={newRequest.startDate || ""} onChange={handleInputChange} required />
        <Input name="endDate" type="date" value={newRequest.endDate || ""} onChange={handleInputChange} required />
        <Select value={newRequest.leaveType} onValueChange={handleSelectChange("leaveType")}>
          <SelectTrigger>
            <SelectValue placeholder="Select leave type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="vacation">Vacation</SelectItem>
            <SelectItem value="sick">Sick Leave</SelectItem>
            <SelectItem value="personal">Personal Leave</SelectItem>
          </SelectContent>
        </Select>
        <Button type="submit">Submit Leave Request</Button>
      </form>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Employee</TableHead>
            <TableHead>Start Date</TableHead>
            <TableHead>End Date</TableHead>
            <TableHead>Leave Type</TableHead>
            <TableHead>Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {leaveRequests.map((request) => (
            <TableRow key={request.id}>
              <TableCell>{request.employeeName}</TableCell>
              <TableCell>{request.startDate}</TableCell>
              <TableCell>{request.endDate}</TableCell>
              <TableCell>{request.leaveType}</TableCell>
              <TableCell>{request.status}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

