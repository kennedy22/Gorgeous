"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface OnboardingTask {
  id: number
  taskName: string
  description: string
  department: string
}

interface EmployeeOnboarding {
  id: number
  employeeName: string
  taskName: string
  status: string
  completedAt: string | null
}

export default function Onboarding() {
  const [onboardingTasks, setOnboardingTasks] = useState<OnboardingTask[]>([])
  const [employeeOnboarding, setEmployeeOnboarding] = useState<EmployeeOnboarding[]>([])
  const [newTask, setNewTask] = useState<Partial<OnboardingTask>>({})
  const [employees, setEmployees] = useState<{ id: string; name: string }[]>([])

  useEffect(() => {
    fetchOnboardingTasks()
    fetchEmployeeOnboarding()
    fetchEmployees()
  }, [])

  const fetchOnboardingTasks = async () => {
    try {
      const response = await fetch("/api/hr/onboarding-tasks")
      if (!response.ok) throw new Error("Failed to fetch onboarding tasks")
      const data = await response.json()
      setOnboardingTasks(data)
    } catch (error) {
      console.error("Error fetching onboarding tasks:", error)
      toast({
        title: "Error",
        description: "Failed to load onboarding tasks. Please try again.",
        variant: "destructive",
      })
    }
  }

  const fetchEmployeeOnboarding = async () => {
    try {
      const response = await fetch("/api/hr/employee-onboarding")
      if (!response.ok) throw new Error("Failed to fetch employee onboarding")
      const data = await response.json()
      setEmployeeOnboarding(data)
    } catch (error) {
      console.error("Error fetching employee onboarding:", error)
      toast({
        title: "Error",
        description: "Failed to load employee onboarding. Please try again.",
        variant: "destructive",
      })
    }
  }

  const fetchEmployees = async () => {
    try {
      const response = await fetch("/api/hr/employees")
      if (!response.ok) throw new Error("Failed to fetch employees")
      const data = await response.json()
      setEmployees(data)
    } catch (error) {
      console.error("Error fetching employees:", error)
      toast({
        title: "Error",
        description: "Failed to load employees. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setNewTask((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/hr/onboarding-tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newTask),
      })
      if (!response.ok) throw new Error("Failed to create onboarding task")
      await fetchOnboardingTasks()
      setNewTask({})
      toast({
        title: "Success",
        description: "Onboarding task created successfully.",
      })
    } catch (error) {
      console.error("Error creating onboarding task:", error)
      toast({
        title: "Error",
        description: "Failed to create onboarding task. Please try again.",
        variant: "destructive",
      })
    }
  }

  const assignTaskToEmployee = async (employeeId: string, taskId: string) => {
    try {
      const response = await fetch("/api/hr/employee-onboarding", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ employeeId, taskId }),
      })
      if (!response.ok) throw new Error("Failed to assign task to employee")
      await fetchEmployeeOnboarding()
      toast({
        title: "Success",
        description: "Task assigned to employee successfully.",
      })
    } catch (error) {
      console.error("Error assigning task to employee:", error)
      toast({
        title: "Error",
        description: "Failed to assign task to employee. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Onboarding</h2>
      <form onSubmit={handleSubmit} className="space-y-2">
        <Input
          name="taskName"
          value={newTask.taskName || ""}
          onChange={handleInputChange}
          placeholder="Task Name"
          required
        />
        <Textarea
          name="description"
          value={newTask.description || ""}
          onChange={handleInputChange}
          placeholder="Task Description"
          required
        />
        <Input
          name="department"
          value={newTask.department || ""}
          onChange={handleInputChange}
          placeholder="Department"
          required
        />
        <Button type="submit">Create Onboarding Task</Button>
      </form>
      <div>
        <h3 className="text-xl font-semibold">Assign Task to Employee</h3>
        <div className="flex space-x-2">
          <Select onValueChange={(employeeId) => setNewTask((prev) => ({ ...prev, employeeId }))}>
            <SelectTrigger>
              <SelectValue placeholder="Select employee" />
            </SelectTrigger>
            <SelectContent>
              {employees.map((employee) => (
                <SelectItem key={employee.id} value={employee.id}>
                  {employee.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select onValueChange={(taskId) => setNewTask((prev) => ({ ...prev, taskId }))}>
            <SelectTrigger>
              <SelectValue placeholder="Select task" />
            </SelectTrigger>
            <SelectContent>
              {onboardingTasks.map((task) => (
                <SelectItem key={task.id} value={task.id.toString()}>
                  {task.taskName}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button onClick={() => assignTaskToEmployee(newTask.employeeId!, newTask.taskId!)}>Assign Task</Button>
        </div>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Employee</TableHead>
            <TableHead>Task</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Completed At</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {employeeOnboarding.map((onboarding) => (
            <TableRow key={onboarding.id}>
              <TableCell>{onboarding.employeeName}</TableCell>
              <TableCell>{onboarding.taskName}</TableCell>
              <TableCell>{onboarding.status}</TableCell>
              <TableCell>{onboarding.completedAt || "Not completed"}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

