"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface PrintJob {
  id: string
  modelName: string
  material: string
  startTime: string
  estimatedEndTime: string
  status: string
}

export default function ThreeDPrintingManagement() {
  const [printJobs, setPrintJobs] = useState<PrintJob[]>([])
  const [newPrintJob, setNewPrintJob] = useState<Partial<PrintJob>>({})

  useEffect(() => {
    fetchPrintJobs()
  }, [])

  const fetchPrintJobs = async () => {
    try {
      const response = await fetch("/api/amt/3d-printing")
      if (!response.ok) throw new Error("Failed to fetch print jobs")
      const data = await response.json()
      setPrintJobs(data)
    } catch (error) {
      console.error("Error fetching print jobs:", error)
      toast({
        title: "Error",
        description: "Failed to load print jobs. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNewPrintJob((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/amt/3d-printing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newPrintJob),
      })
      if (!response.ok) throw new Error("Failed to create print job")
      await fetchPrintJobs()
      setNewPrintJob({})
      toast({
        title: "Success",
        description: "Print job created successfully.",
      })
    } catch (error) {
      console.error("Error creating print job:", error)
      toast({
        title: "Error",
        description: "Failed to create print job. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">3D Printing Management</h2>
      <form onSubmit={handleSubmit} className="space-y-2">
        <Input
          name="modelName"
          value={newPrintJob.modelName || ""}
          onChange={handleInputChange}
          placeholder="Model Name"
          required
        />
        <Input
          name="material"
          value={newPrintJob.material || ""}
          onChange={handleInputChange}
          placeholder="Material"
          required
        />
        <Input
          name="startTime"
          type="datetime-local"
          value={newPrintJob.startTime || ""}
          onChange={handleInputChange}
          required
        />
        <Input
          name="estimatedEndTime"
          type="datetime-local"
          value={newPrintJob.estimatedEndTime || ""}
          onChange={handleInputChange}
          required
        />
        <Button type="submit">Create Print Job</Button>
      </form>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Model Name</TableHead>
            <TableHead>Material</TableHead>
            <TableHead>Start Time</TableHead>
            <TableHead>Estimated End Time</TableHead>
            <TableHead>Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {printJobs.map((job) => (
            <TableRow key={job.id}>
              <TableCell>{job.modelName}</TableCell>
              <TableCell>{job.material}</TableCell>
              <TableCell>{new Date(job.startTime).toLocaleString()}</TableCell>
              <TableCell>{new Date(job.estimatedEndTime).toLocaleString()}</TableCell>
              <TableCell>{job.status}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

