"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface Printer {
  id: string
  name: string
  model: string
  ipAddress: string
  status: string
}

export default function ThreeDPrinterControl() {
  const [printers, setPrinters] = useState<Printer[]>([])
  const [newPrinter, setNewPrinter] = useState<Partial<Printer>>({})

  useEffect(() => {
    fetchPrinters()
  }, [])

  const fetchPrinters = async () => {
    try {
      const response = await fetch("/api/amt/3d-printers")
      if (!response.ok) throw new Error("Failed to fetch printers")
      const data = await response.json()
      setPrinters(data)
    } catch (error) {
      console.error("Error fetching printers:", error)
      toast({
        title: "Error",
        description: "Failed to load printers. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNewPrinter((prev) => ({ ...prev, [name]: value }))
  }

  const handleAddPrinter = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/amt/3d-printers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newPrinter),
      })
      if (!response.ok) throw new Error("Failed to add printer")
      await fetchPrinters()
      setNewPrinter({})
      toast({
        title: "Success",
        description: "Printer added successfully.",
      })
    } catch (error) {
      console.error("Error adding printer:", error)
      toast({
        title: "Error",
        description: "Failed to add printer. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleAction = async (printerId: string, action: string) => {
    try {
      const response = await fetch(`/api/amt/3d-printers/${printerId}/${action}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      })
      if (!response.ok) throw new Error(`Failed to ${action} printer`)
      await fetchPrinters()
      toast({
        title: "Success",
        description: `Printer ${action}ed successfully.`,
      })
    } catch (error) {
      console.error(`Error ${action}ing printer:`, error)
      toast({
        title: "Error",
        description: `Failed to ${action} printer. Please try again.`,
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">3D Printer Control</h2>
      <form onSubmit={handleAddPrinter} className="space-y-2">
        <Input
          name="name"
          value={newPrinter.name || ""}
          onChange={handleInputChange}
          placeholder="Printer Name"
          required
        />
        <Input name="model" value={newPrinter.model || ""} onChange={handleInputChange} placeholder="Printer Model" />
        <Input
          name="ipAddress"
          value={newPrinter.ipAddress || ""}
          onChange={handleInputChange}
          placeholder="IP Address"
          required
        />
        <Button type="submit">Add Printer</Button>
      </form>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Model</TableHead>
            <TableHead>IP Address</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {printers.map((printer) => (
            <TableRow key={printer.id}>
              <TableCell>{printer.name}</TableCell>
              <TableCell>{printer.model}</TableCell>
              <TableCell>{printer.ipAddress}</TableCell>
              <TableCell>{printer.status}</TableCell>
              <TableCell>
                <Button variant="outline" size="sm" onClick={() => handleAction(printer.id, "start")}>
                  Start
                </Button>
                <Button variant="outline" size="sm" onClick={() => handleAction(printer.id, "stop")}>
                  Stop
                </Button>
                <Button variant="destructive" size="sm" onClick={() => handleAction(printer.id, "reset")}>
                  Reset
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

