"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface PrintingMaterial {
  id: string
  name: string
  type: string
  quantity: number
  unit: string
  reorderPoint: number
}

export default function PrintingMaterialInventory() {
  const [materials, setMaterials] = useState<PrintingMaterial[]>([])
  const [newMaterial, setNewMaterial] = useState<Partial<PrintingMaterial>>({})

  useEffect(() => {
    fetchMaterials()
  }, [])

  const fetchMaterials = async () => {
    try {
      const response = await fetch("/api/amt/printing-materials")
      if (!response.ok) throw new Error("Failed to fetch printing materials")
      const data = await response.json()
      setMaterials(data)
    } catch (error) {
      console.error("Error fetching printing materials:", error)
      toast({
        title: "Error",
        description: "Failed to load printing materials. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNewMaterial((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/amt/printing-materials", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newMaterial),
      })
      if (!response.ok) throw new Error("Failed to add printing material")
      await fetchMaterials()
      setNewMaterial({})
      toast({
        title: "Success",
        description: "Printing material added successfully.",
      })
    } catch (error) {
      console.error("Error adding printing material:", error)
      toast({
        title: "Error",
        description: "Failed to add printing material. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">3D Printing Material Inventory</h2>
      <form onSubmit={handleSubmit} className="space-y-2">
        <Input
          name="name"
          value={newMaterial.name || ""}
          onChange={handleInputChange}
          placeholder="Material Name"
          required
        />
        <Input
          name="type"
          value={newMaterial.type || ""}
          onChange={handleInputChange}
          placeholder="Material Type"
          required
        />
        <Input
          name="quantity"
          type="number"
          value={newMaterial.quantity || ""}
          onChange={handleInputChange}
          placeholder="Quantity"
          required
        />
        <Input name="unit" value={newMaterial.unit || ""} onChange={handleInputChange} placeholder="Unit" required />
        <Input
          name="reorderPoint"
          type="number"
          value={newMaterial.reorderPoint || ""}
          onChange={handleInputChange}
          placeholder="Reorder Point"
          required
        />
        <Button type="submit">Add Material</Button>
      </form>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Quantity</TableHead>
            <TableHead>Unit</TableHead>
            <TableHead>Reorder Point</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {materials.map((material) => (
            <TableRow key={material.id}>
              <TableCell>{material.name}</TableCell>
              <TableCell>{material.type}</TableCell>
              <TableCell>{material.quantity}</TableCell>
              <TableCell>{material.unit}</TableCell>
              <TableCell>{material.reorderPoint}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

