"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface Lead {
  id: number
  name: string
  email: string
  phone: string
  status: string
}

export default function LeadManagement() {
  const [leads, setLeads] = useState<Lead[]>([])
  const [newLead, setNewLead] = useState<Partial<Lead>>({})

  useEffect(() => {
    fetchLeads()
  }, [])

  const fetchLeads = async () => {
    try {
      const response = await fetch("/api/crm/leads")
      if (!response.ok) throw new Error("Failed to fetch leads")
      const data = await response.json()
      setLeads(data)
    } catch (error) {
      console.error("Error fetching leads:", error)
      toast({
        title: "Error",
        description: "Failed to load leads. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNewLead((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/crm/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newLead),
      })
      if (!response.ok) throw new Error("Failed to create lead")
      await fetchLeads()
      setNewLead({})
      toast({
        title: "Success",
        description: "Lead created successfully.",
      })
    } catch (error) {
      console.error("Error creating lead:", error)
      toast({
        title: "Error",
        description: "Failed to create lead. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Lead Management</h2>
      <form onSubmit={handleSubmit} className="space-y-2">
        <Input name="name" value={newLead.name || ""} onChange={handleInputChange} placeholder="Name" required />
        <Input
          name="email"
          type="email"
          value={newLead.email || ""}
          onChange={handleInputChange}
          placeholder="Email"
          required
        />
        <Input name="phone" value={newLead.phone || ""} onChange={handleInputChange} placeholder="Phone" />
        <Button type="submit">Add Lead</Button>
      </form>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Phone</TableHead>
            <TableHead>Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {leads.map((lead) => (
            <TableRow key={lead.id}>
              <TableCell>{lead.name}</TableCell>
              <TableCell>{lead.email}</TableCell>
              <TableCell>{lead.phone}</TableCell>
              <TableCell>{lead.status}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}

