"use client"

import type React from "react"
import { useRef } from "react"
import { useReactToPrint } from "react-to-print"
import { Button } from "@/components/ui/button"
import { Printer } from "lucide-react"

interface PrintableDocumentProps {
  children: React.ReactNode
  documentTitle: string
}

export const PrintableDocument: React.FC<PrintableDocumentProps> = ({ children, documentTitle }) => {
  const componentRef = useRef(null)

  const handlePrint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle: documentTitle,
  })

  return (
    <div>
      <div className="mb-4">
        <Button onClick={handlePrint} className="print:hidden">
          <Printer className="mr-2 h-4 w-4" /> Print Document
        </Button>
      </div>
      <div ref={componentRef} className="print:p-4">
        {children}
      </div>
    </div>
  )
}

