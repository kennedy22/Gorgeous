"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface Company {
  id: number
  name: string
  legalName: string
  taxId: string
  address: string
}

interface Branch {
  id: number
  companyId: number
  name: string
  address: string
}

export default function CompanyBranchManager() {
  const [companies, setCompanies] = useState<Company[]>([])
  const [branches, setBranches] = useState<Branch[]>([])
  const [newCompany, setNewCompany] = useState<Partial<Company>>({})
  const [newBranch, setNewBranch] = useState<Partial<Branch>>({})

  useEffect(() => {
    fetchCompanies()
    fetchBranches()
  }, [])

  const fetchCompanies = async () => {
    try {
      const response = await fetch("/api/admin/companies")
      if (!response.ok) throw new Error("Failed to fetch companies")
      const data = await response.json()
      setCompanies(data)
    } catch (error) {
      console.error("Error fetching companies:", error)
      toast({
        title: "Error",
        description: "Failed to load companies. Please try again.",
        variant: "destructive",
      })
    }
  }

  const fetchBranches = async () => {
    try {
      const response = await fetch("/api/admin/branches")
      if (!response.ok) throw new Error("Failed to fetch branches")
      const data = await response.json()
      setBranches(data)
    } catch (error) {
      console.error("Error fetching branches:", error)
      toast({
        title: "Error",
        description: "Failed to load branches. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleCompanyInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNewCompany((prev) => ({ ...prev, [name]: value }))
  }

  const handleBranchInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setNewBranch((prev) => ({ ...prev, [name]: value }))
  }

  const handleAddCompany = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/admin/companies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newCompany),
      })
      if (!response.ok) throw new Error("Failed to add company")
      await fetchCompanies()
      setNewCompany({})
      toast({
        title: "Success",
        description: "Company added successfully.",
      })
    } catch (error) {
      console.error("Error adding company:", error)
      toast({
        title: "Error",
        description: "Failed to add company. Please try again.",
        variant: "destructive",
      })
    }
  }

  const handleAddBranch = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      const response = await fetch("/api/admin/branches", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newBranch),
      })
      if (!response.ok) throw new Error("Failed to add branch")
      await fetchBranches()
      setNewBranch({})
      toast({
        title: "Success",
        description: "Branch added successfully.",
      })
    } catch (error) {
      console.error("Error adding branch:", error)
      toast({
        title: "Error",
        description: "Failed to add branch. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-4">Companies</h2>
        <form onSubmit={handleAddCompany} className="space-y-2 mb-4">
          <Input
            name="name"
            value={newCompany.name || ""}
            onChange={handleCompanyInputChange}
            placeholder="Company Name"
            required
          />
          <Input
            name="legalName"
            value={newCompany.legalName || ""}
            onChange={handleCompanyInputChange}
            placeholder="Legal Name"
          />
          <Input name="taxId" value={newCompany.taxId || ""} onChange={handleCompanyInputChange} placeholder="Tax ID" />
          <Input
            name="address"
            value={newCompany.address || ""}
            onChange={handleCompanyInputChange}
            placeholder="Address"
          />
          <Button type="submit">Add Company</Button>
        </form>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Legal Name</TableHead>
              <TableHead>Tax ID</TableHead>
              <TableHead>Address</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {companies.map((company) => (
              <TableRow key={company.id}>
                <TableCell>{company.name}</TableCell>
                <TableCell>{company.legalName}</TableCell>
                <TableCell>{company.taxId}</TableCell>
                <TableCell>{company.address}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      <div>
        <h2 className="text-2xl font-bold mb-4">Branches</h2>
        <form onSubmit={handleAddBranch} className="space-y-2 mb-4">
          <select
            name="companyId"
            value={newBranch.companyId || ""}
            onChange={(e) => setNewBranch({ ...newBranch, companyId: Number.parseInt(e.target.value) })}
            className="w-full p-2 border rounded"
            required
          >
            <option value="">Select Company</option>
            {companies.map((company) => (
              <option key={company.id} value={company.id}>
                {company.name}
              </option>
            ))}
          </select>
          <Input
            name="name"
            value={newBranch.name || ""}
            onChange={handleBranchInputChange}
            placeholder="Branch Name"
            required
          />
          <Input
            name="address"
            value={newBranch.address || ""}
            onChange={handleBranchInputChange}
            placeholder="Branch Address"
          />
          <Button type="submit">Add Branch</Button>
        </form>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Company</TableHead>
              <TableHead>Branch Name</TableHead>
              <TableHead>Address</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {branches.map((branch) => (
              <TableRow key={branch.id}>
                <TableCell>{companies.find((c) => c.id === branch.companyId)?.name}</TableCell>
                <TableCell>{branch.name}</TableCell>
                <TableCell>{branch.address}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

