const { execSync } = require("child_process")
const fs = require("fs")
const path = require("path")

// Build the Next.js application
console.log("Building Next.js application...")
execSync("npm run build", { stdio: "inherit" })

// Build the Electron application
console.log("Building Electron application...")
execSync("npm run build-electron", { stdio: "inherit" })

// Copy additional files to the dist folder
const distPath = path.join(__dirname, "dist")
fs.copyFileSync(path.join(__dirname, "README.txt"), path.join(distPath, "README.txt"))

console.log("Build completed successfully!")

