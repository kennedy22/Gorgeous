Gorgeous Investment ERP

To start the application:

1. Double-click on the 'GorgeousInvestmentERP.exe' file.

If this is your first time running the application, you will be prompted to enter configuration details.

For any issues or support, please contact our support team at support@gorgeousinvestment.com

