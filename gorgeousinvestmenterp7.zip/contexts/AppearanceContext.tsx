"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

interface AppearanceSettings {
  primaryColor: string
  secondaryColor: string
  accentColor: string
  dashboardLayout: "grid" | "list" | "compact"
  darkMode: boolean
}

interface AppearanceContextType {
  appearance: AppearanceSettings
  updateAppearance: (settings: Partial<AppearanceSettings>) => void
}

const AppearanceContext = createContext<AppearanceContextType | undefined>(undefined)

export function AppearanceProvider({ children }: { children: React.ReactNode }) {
  const [appearance, setAppearance] = useState<AppearanceSettings>({
    primaryColor: "#000000",
    secondaryColor: "#ffffff",
    accentColor: "#3b82f6",
    dashboardLayout: "grid",
    darkMode: false,
  })

  useEffect(() => {
    // Load appearance settings from local storage or API
    const savedAppearance = localStorage.getItem("appearanceSettings")
    if (savedAppearance) {
      setAppearance(JSON.parse(savedAppearance))
    }
  }, [])

  const updateAppearance = (newSettings: Partial<AppearanceSettings>) => {
    const updatedAppearance = { ...appearance, ...newSettings }
    setAppearance(updatedAppearance)
    localStorage.setItem("appearanceSettings", JSON.stringify(updatedAppearance))

    // Apply the new settings
    document.documentElement.style.setProperty("--primary-color", updatedAppearance.primaryColor)
    document.documentElement.style.setProperty("--secondary-color", updatedAppearance.secondaryColor)
    document.documentElement.style.setProperty("--accent-color", updatedAppearance.accentColor)
    document.documentElement.classList.toggle("dark", updatedAppearance.darkMode)
  }

  return <AppearanceContext.Provider value={{ appearance, updateAppearance }}>{children}</AppearanceContext.Provider>
}

export function useAppearance() {
  const context = useContext(AppearanceContext)
  if (context === undefined) {
    throw new Error("useAppearance must be used within an AppearanceProvider")
  }
  return context
}

