"use client"

import { useState } from "react"
import { View, StyleSheet } from "react-native"
import { TextInput, Button, Title } from "react-native-paper"
import { useAuth } from "../contexts/AuthContext"

const LoginScreen = ({ navigation }) => {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const { login } = useAuth()

  const handleLogin = async () => {
    try {
      await login(username, password)
      navigation.navigate("Dashboard")
    } catch (error) {
      console.error("Login failed:", error)
      // Show error message to user
    }
  }

  return (
    <View style={styles.container}>
      <Title style={styles.title}>Gorgeous Investment ERP</Title>
      <TextInput label="Username" value={username} onChangeText={setUsername} style={styles.input} />
      <TextInput label="Password" value={password} onChangeText={setPassword} secureTextEntry style={styles.input} />
      <Button mode="contained" onPress={handleLogin} style={styles.button}>
        Login
      </Button>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    padding: 16,
  },
  title: {
    fontSize: 24,
    marginBottom: 24,
    textAlign: "center",
  },
  input: {
    marginBottom: 12,
  },
  button: {
    marginTop: 24,
  },
})

export default LoginScreen

