import { View, StyleSheet } from "react-native"
import { Title, Card, Paragraph } from "react-native-paper"

const DashboardScreen = () => {
  return (
    <View style={styles.container}>
      <Title style={styles.title}>Dashboard</Title>
      <Card style={styles.card}>
        <Card.Title title="Sales Overview" />
        <Card.Content>
          <Paragraph>Total Sales: $10,000</Paragraph>
          <Paragraph>Orders: 50</Paragraph>
        </Card.Content>
      </Card>
      <Card style={styles.card}>
        <Card.Title title="Inventory Status" />
        <Card.Content>
          <Paragraph>Low Stock Items: 5</Paragraph>
          <Paragraph>Total Products: 100</Paragraph>
        </Card.Content>
      </Card>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  title: {
    fontSize: 24,
    marginBottom: 24,
  },
  card: {
    marginBottom: 16,
  },
})

export default DashboardScreen

