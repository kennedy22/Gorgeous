const { Client } = require("pg")
const fs = require("fs")
const path = require("path")

const client = new Client({
  user: "erp_user",
  host: "localhost",
  database: "gorgeous_investment_erp",
  password: "erp_password",
  port: 5432,
})

async function initDatabase() {
  try {
    await client.connect()

    const schemaPath = path.join(__dirname, "lib", "db", "init-db.ts")
    const schemaContent = fs.readFileSync(schemaPath, "utf8")

    // Extract SQL statements from the TypeScript file
    const sqlStatements = schemaContent.match(/`([\s\S]*?)`/g)

    if (sqlStatements) {
      for (const statement of sqlStatements) {
        const cleanStatement = statement.replace(/`/g, "").trim()
        if (cleanStatement) {
          await client.query(cleanStatement)
        }
      }
    }

    console.log("Database initialized successfully")
  } catch (error) {
    console.error("Error initializing database:", error)
  } finally {
    await client.end()
  }
}

initDatabase()

