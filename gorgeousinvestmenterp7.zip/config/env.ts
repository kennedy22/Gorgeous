export const requiredEnvVariables = [
  "POSTGRES_URL",
  "JWT_SECRET_KEY",
  "OPENAI_API_KEY",
  "TWILIO_ACCOUNT_SID",
  "TWILIO_AUTH_TOKEN",
  "TWILIO_WHATSAPP_NUMBER",
  "TWILIO_PHONE_NUMBER",
  "MPESA_CONSUMER_KEY",
  "MPESA_CONSUMER_SECRET",
  "MPESA_SHORTCODE",
  "MPESA_PASSKEY",
  "BASE_URL",
]

export function validateEnv() {
  const missingVars = requiredEnvVariables.filter((varName) => !(varName in process.env))

  if (missingVars.length > 0) {
    throw new Error(`The following environment variables are missing: ${missingVars.join(", ")}`)
  }
}

